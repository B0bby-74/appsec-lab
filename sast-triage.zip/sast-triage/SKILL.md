---
name: sast-triage
description: Triage, fix, suppress or risk-accept security findings from SAST/secret/DAST scanners — Semgrep CE, Snyk Code, gosec, Bandit, Brakeman, SpotBugs/FindSecBugs, ESLint security plugins, njsscan, TruffleHog, Invicti, and findings aggregated in Kondukto. Use whenever the user shares scanner output (SARIF/JSON/XML), a finding ID, a Kondukto/Snyk/Invicti issue, or asks whether a finding is a false positive, what its root cause is (source to sink), how to fix it, how to suppress it, or how to record a risk acceptance.
---

# SAST finding triage

Goal: for every finding, produce a verdict that **someone other than you can verify**, backed by a file:line source→sink trace, and leave behind a fix, a scoped suppression, or a time-boxed risk-acceptance record.

## Inputs — insist on raw material

Work from, in this order of preference:
1. **The scanner's native output** (SARIF/JSON/XML), not a dashboard summary or a pasted one-liner. See `references/scanners/<tool>.md` for the exact command and where the dataflow trace lives in the output.
2. **The source at the scanned commit.** Check `git rev-parse HEAD` against the commit in the scan metadata; if they differ, say so and re-locate the finding (line numbers drift).
3. **The rule that fired** (Semgrep YAML, Bandit plugin, FindSecBugs detector). Knowing exactly what the rule matches is how false positives get proven.
4. Entry points and framework config: routes, controllers, middleware, auth decorators, ORM/template auto-escaping settings, dependency versions.
5. Deployment context when available (internet-facing? authenticated? internal network only?). If unknown, state the assumption.

If only a summary is available, triage it but mark the verdict **provisional** and list what raw input would confirm it.

Normalize first when there is more than one finding or more than one scanner:
```bash
python3 ~/.claude/skills/sast-triage/scripts/normalize.py scan1.sarif bandit.json gosec.json > findings.json
```
(Use the skill's actual path if installed at project level: `.claude/skills/sast-triage/scripts/normalize.py`.) It auto-detects the format, emits one record per finding with CWE, rule, file, line, trace (when the tool's output has one), `duplicates` (same CWE/file/line) and `related` (same CWE/file within 5 lines from another tool — e.g. Bandit flags where SQL is built, Semgrep where it executes; confirm before merging). It never prints secret values.

## Workflow per finding (or duplicate group)

### 1. Identify
Record: scanner + version, rule ID, CWE, file:line, scanned commit, scanner severity/confidence, finding ID/fingerprint (Kondukto ID, Snyk ID, Brakeman fingerprint, SARIF `partialFingerprints`).

### 2. Trace source → sink (root cause)
Build the trace yourself even if the scanner gave one — scanner traces skip steps and some tools (Bandit, gosec, ESLint, most njsscan rules) give **no trace at all**, only the sink line.

```
SOURCE   file:line  where untrusted data enters (request param, header, body, file, env, DB row written by users, message queue)
STEP n   file:line  each assignment / call / return that carries it (note any transformation)
SANITIZER file:line  validation/encoding/parameterization — or "none"
SINK     file:line  the dangerous API (query exec, shell, eval, file open, template render w/o escaping, redirect, deserialize)
```
Method: start at the sink, walk callers backward (grep/IDE "find usages"), until you reach an entry point or a constant. Then answer:
- **Reachability:** does any externally reachable entry point lead here? Name it (route + method).
- **Attacker control:** which part of the value can the attacker shape?
- **Sanitizer fitness:** is the control correct *for this sink's context*? Use `references/sink-sanitizer-matrix.md`. HTML-escaping does not stop SQLi; `path.normalize` does not stop traversal; regex allow-lists must be anchored.
- **Root cause in one sentence**, phrased as the design flaw, e.g. "Query built by string concatenation of `req.query.id` instead of a bound parameter."

For Invicti (DAST) the trace starts from the HTTP request/response proof: map URL → route → handler, then walk forward to the sink. See `references/scanners/invicti.md`.

For TruffleHog follow `references/scanners/trufflehog.md` instead — there is no source→sink; the questions are *is it live, where else is it, who used it*.

### 3. Verdict — exactly one
| Verdict | Meaning | Evidence required |
|---|---|---|
| **True Positive** | Reachable, attacker-controlled, no adequate control | Trace + PoC (test, curl, or concrete payload) |
| **False Positive** | Scanner is wrong about the code: value is constant, path doesn't exist, rule mismatched API | Trace showing why + quote of what the rule matched |
| **Not Exploitable** | Path is real but a named control blocks it | Trace + file:line of the control + why it fits the sink |
| **Risk Accepted** | Real and exploitable-ish; business chooses not to fix now | Risk record (owner, approver, expiry) — see templates |
| **Duplicate** | Same root cause as another finding | ID of the primary finding |

Be strict about FP vs Not Exploitable: "the scanner matched a safe pattern" is FP; "it's vulnerable but a WAF/validator stops it" is Not Exploitable — the latter breaks if the control is removed, so record the dependency.

When unsure, say **Needs Review** and list the exact unanswered question. Never default to FP to clear a queue.

Lessons from validation runs (each caused a wrong verdict once):
- **Read the whole enclosing function and every handler registered on the object** (`.on("doctype", …)`, callbacks, middleware) — not a window of lines around the sink. If any callee on the path is unseen, the verdict is Needs Review, never FP.
- **Verify helpers by reading their bodies.** `getSafeValue()`, `doSomething()`, `isValid()` often decide the verdict (constant return, pass-through, always-true). Name the helper file:line in the trace.
- **Dead branches decide many FPs** (`if (7*42-86 > 200)`, `switch` on a constant, value overwritten by a later assignment, list index after `remove(0)`). Evaluate them explicitly and quote the arithmetic.
- **Environment decides some verdicts:** log level (debug logs off in production), debug/dev-only flags, framework auto-escaping. Check the production config before calling TP or FP; otherwise state the assumption.
- **Treat `Host`, `X-Forwarded-*`, `Referer`, cookies and the parameter *name* as attacker input.** For reflected XSS from a *custom* header, note the attacker usually cannot make a victim's browser send it (lower severity / Not Exploitable unless stored or cache-poisonable); `Referer` is attacker-influenceable.
- **"Audit" rules match a pattern, not a vulnerability** (Semgrep rules under `/audit/`, ESLint `detect-object-injection`, FindSecBugs `*_INJECTION` on any non-constant). Their firing is weak evidence; the trace decides.
- **Fix the right CWE even if the rule is narrower:** e.g. a rule for MD5 passwords not firing on unsalted SHA-256 does not make SHA-256 password storage safe (CWE-916).

### 4. Contextual severity
Re-score with CVSS v4.0 (or the org's model) using reachability, auth required, exposure, data sensitivity. Show scanner severity → adjusted severity and the reason.

### 5a. True Positive → fix
- Fix at the right layer: parameterized query, safe API, framework encoder, allow-list — not ad-hoc escaping or blocklists. Prefer the matrix's "correct control".
- **No known residual path.** If you can name a way the issue still occurs after your change (guessable file names still downloadable, `includes()` allow-list bypassable, limit stated only in an LLM prompt instead of enforced in code), it is a *partial* fix — don't ship it as the fix. Choose the complete one (remove the exposure; relocate legitimate content; enforce server-side) and list the functional cost explicitly, or record the residual as a risk acceptance. Never silently trade completeness for preserving functionality.
- Check the fix keeps behaviour correct (e.g. parameterizing a login query but dropping the password hashing breaks login).
- Number each code change point `SEC-FIX01`, `SEC-FIX02`, … per finding. At each change point add one short comment:
  `// SEC-FIX01 <finding-id> CWE-89: bind id as parameter instead of concatenation`
  (Use the language's comment syntax.) The comment is a locator, not the record.
- The full record goes in the commit message / PR description / ticket using the **Fix record** template in `references/templates.md`: for each FIXnn — file:line, before snippet, after snippet, why.
- Add a regression test that **fails on the old code and passes on the new** (payload from the PoC). If you cannot run it, say so.
- **Variant analysis:** search for the same pattern elsewhere (grep, or a quick Semgrep rule — see `references/scanners/semgrep.md`). List other hits; fix or file them.
- **Verify:** re-run the same scanner and rule version on the changed code; the finding must disappear and no new findings appear. Report the command and result.

### 5b. False Positive / Not Exploitable → scoped suppression
- Write the justification with the template in `references/templates.md` (trace + why).
- Suppress in the scanner's native syntax, **scoped to one rule ID on one line/location**, with the reason and ticket reference inline. Syntax per tool: `references/scanners/<tool>.md`. Never blanket-suppress (`# nosec` without ID, `eslint-disable` without a rule, path-wide ignores) unless the path is genuinely out of scope (tests, vendored code) and you say so.
- If findings flow through Kondukto / Snyk / Invicti, also mark the state there so it persists across re-scans; in SARIF use `result.suppressions[]` with `kind`, `status`, `justification`.
- Not Exploitable: name the control in the suppression reason so a reviewer sees the dependency.

### 5c. Risk Accepted → record, not a comment
Produce the **Risk acceptance record** from `references/templates.md`: owner, approver (not the same person), rationale, compensating controls, residual risk, expiry date (default ≤ 90 days for High/Critical, ≤ 180 for Medium), review date, ticket. Record it in Kondukto (or the org's tracker). Any code-level suppression must reference the record ID and expiry. Without an approver the status is "Risk acceptance requested", not accepted.

## Output
For each finding/group, emit the matching template from `references/templates.md`. For a batch, start with a summary table: ID | scanner(s) | CWE | file:line | verdict | adjusted severity | action. Group duplicates.

## What counts as done (external checks, not your opinion)
- TP: re-scan with the same rule version is clean for that finding **and** the regression test passes.
- FP / Not Exploitable: the trace is specific enough that a second reviewer can reproduce the reasoning from file:line references alone; suppression is rule-scoped.
- Risk accepted: an approver other than the owner signed it, with an expiry.
- Secret: provider confirms revocation / TruffleHog reports it unverified; history cleaned or the exposure documented.

State plainly which of these checks you actually ran and which remain for the user.

## References
- `references/scanners/` — one file per tool: run command, output fields, where the trace is, suppression syntax, common FPs
- `references/sink-sanitizer-matrix.md` — CWE → sinks → correct control → controls that look right but aren't
- `references/templates.md` — verdict, fix record, suppression justification, risk acceptance
- `references/validation.md` — how to measure this skill's accuracy on known-answer benchmark apps
- `references/validation-results.md` — measured scanner and triage accuracy (latest run) and known gaps
