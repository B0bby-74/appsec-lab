---
name: sast-triage
description: Analyse ONE security scanner finding at a time and give its root cause (source to sink), verdict (true positive / false positive / not exploitable / risk accepted), remediation and exact fix details with SEC-FIX tracking comments. Works for findings from Semgrep CE, Snyk Code, gosec, Bandit, Brakeman, SpotBugs/FindSecBugs, ESLint security plugins, njsscan, TruffleHog, Invicti and Kondukto. Use when the user opens or selects the code line a scanner flagged and asks to triage, fix, remediate or explain it, or runs /sast-triage.
argument-hint: "<scanner> <rule or issue title> [file:line]   e.g. bandit B608 SQL injection app/db.py:42"
---

# One finding → remediation and fix details

The user's process:
1. They search their project for **one** finding and open the flagged file and line in the editor (often with the line selected).
2. They run this skill, e.g. `/sast-triage bandit B608 SQL injection` (or with `app/db.py:42`).
3. They expect a **Finding Report** with root cause, verdict, remediation and fix details, and then decide whether to apply the fix.

Finding given by the user: **$ARGUMENTS**

## Step 0 — Pin down the finding (don't guess)
Collect these four things. Use, in order: the arguments above, the user's current editor selection / open file, then the conversation.
- **Scanner** (Bandit, Semgrep, Snyk, …)
- **Rule ID or issue title** (B608, `javascript/Sqli`, `SQL_INJECTION_JDBC`, …)
- **File and line**
- **Finding ID** if they have one (Kondukto/Snyk/scanner ID). If none, use `<FILE>-L<LINE>` as the ID.

If the file or line is missing and there is no editor selection, ask **one** short question for it, then stop until answered. If the line in the file doesn't contain anything resembling the flagged pattern, say so and ask whether the code changed since the scan.

## Step 1 — Read the code properly
- Read the **whole function** containing the line, and the whole file if it is short.
- Follow every value used at the flagged line **backwards** to where it comes from (callers, routes, helpers). Open helper functions and read their bodies — `isValid()`, `getSafeValue()`, `doSomething()` often decide the verdict.
- Check handlers registered on the same object (`.on("doctype", …)`, middleware, callbacks).
- Look up the scanner's notes in `references/scanners/<tool>.md` (what the rule really matches, common false positives, suppression syntax) and the right control in `references/sink-sanitizer-matrix.md`.

## Step 2 — Decide, using these rules
- **Source → sink:** where does untrusted data enter (request param/header/body/cookie, parameter *name*, `Host`/`X-Forwarded-*`/`Referer`, file, env, user-written DB row) and does it reach the flagged dangerous call?
- **Dead branches and constants decide many false positives** (`if (7*42-86 > 200)`, `switch` on a constant, value overwritten later, list index after `remove(0)`). Evaluate them and quote the arithmetic.
- **Does the control fit the sink?** HTML-escaping doesn't stop SQL injection; `normalize` without a prefix check doesn't stop traversal; `includes()` allow-lists are bypassable; a limit written only in an LLM prompt is not enforced.
- **Environment matters:** debug-only logging, dev-only flags, framework auto-escaping — check config, or state the assumption.
- **Audit-style rules** (Semgrep `/audit/`, ESLint `detect-object-injection`, FindSecBugs injection rules) fire on patterns; the trace decides, not the rule firing.
- If anything on the path is unseen or uncertain → verdict **Needs Review** with the exact open question. Never call it a false positive to make it go away.

Verdicts — pick exactly one:
| Verdict | Means |
|---|---|
| **True Positive** | Attacker-controlled data reaches the sink with no adequate control |
| **False Positive** | Scanner is wrong: constant value, path doesn't exist, rule matched a safe API |
| **Not Exploitable** | Path is real but a named control blocks it (breaks if the control is removed) |
| **Risk Accepted** | Real, but the business decides not to fix now (needs owner, approver, expiry) |
| **Needs Review** | Can't decide from the code available — say what's missing |

For **TruffleHog** (secrets) follow `references/scanners/trufflehog.md` instead: revoke/rotate first; editing code alone never fixes a leaked secret.
For **Invicti** (DAST) map the URL → route → handler first: `references/scanners/invicti.md`.

## Step 3 — Write the Finding Report (always this exact layout)

```
═══ FINDING REPORT ═══════════════════════════════════════════
Finding   : <ID>   Scanner: <tool>   Rule: <rule>   CWE-<n> <name>
Location  : <file>:<line>
Verdict   : TRUE POSITIVE | FALSE POSITIVE | NOT EXPLOITABLE | RISK ACCEPTED | NEEDS REVIEW
Severity  : scanner <x> → adjusted <y>  (why: exposure / auth / data)

ROOT CAUSE
  <one sentence: the design flaw, e.g. "SQL built by concatenating request.args['id'] instead of a bound parameter">

SOURCE → SINK
  SOURCE     <file>:<line>  <code>     ← where untrusted data enters
  STEP       <file>:<line>  <code>     ← each hop that carries it
  SANITIZER  <file>:<line>  <code> | none   ← does it fit this sink?
  SINK       <file>:<line>  <code>     ← the dangerous call
  Entry point: <route/method or caller>    Attacker controls: <which part>

REMEDIATION
  <what to change and why it removes the root cause; name the correct control>
  <any functional cost or residual risk, stated plainly>

FIX DETAILS
  SEC-FIX01  <file>:<line>
    Before : <code>
    After  : <code>
    Comment: <comment syntax> SEC-FIX01 <ID> CWE-<n>: <what changed>
  SEC-FIX02  ...                    (one block per change point)

VERIFY
  Re-scan : <exact command for the same scanner/rule>  → finding should be gone
  Test    : <test that fails on old code, passes on new — file + payload>
  Similar code: <other places with the same pattern, or "none found (searched: <pattern>)">
═══════════════════════════════════════════════════════════════
```

Section changes by verdict:
- **False Positive / Not Exploitable:** replace REMEDIATION/FIX DETAILS with **JUSTIFICATION** (why it's safe, citing file:lines; for Not Exploitable name the control it depends on) and **SUPPRESSION** — the exact one-line suppression in the scanner's own syntax, limited to that rule ID, with reason and ID (syntax in `references/scanners/<tool>.md`), plus "also mark as false positive in Kondukto/Snyk/Invicti" if they use one.
- **Risk Accepted:** replace with the **Risk acceptance record** from `references/templates.md` (owner, different approver, compensating controls, expiry ≤90 days High/Critical, ≤180 Medium). Without an approver, status is *Requested*.
- **Needs Review:** list the exact questions/files needed; no fix yet.

Fix rules:
- Fix at the right layer (bound parameters, safe API, framework encoder, exact allow-list, server-side enforcement) — not blocklists or ad-hoc escaping.
- **No known way around it.** If you can name a way the issue still happens after the change, it's a partial fix: give the complete fix and state its cost.
- Keep behaviour working (e.g. parameterize the login query *and* keep password hashing).
- Number change points `SEC-FIX01`, `SEC-FIX02`… per finding; one short comment at each change point.

## Step 4 — Ask before changing code
End the report with exactly:

> **Apply this fix?** Reply **yes** to apply SEC-FIX changes, **suppress** to add the suppression instead, or **no** to leave the code unchanged.

Do not edit files before the user answers. When they say yes:
1. Make only the listed SEC-FIX changes, each with its one-line comment.
2. Add the regression test if the project has a test setup; otherwise give it in the report.
3. Run the re-scan command and the test if the tools are installed; report the real result (or say they weren't run).
4. Save the report to `security-scans/<ID>.md` (create the folder if needed) and tell the user the path. They can review the code changes in VS Code's Source Control panel.

## References
- `references/scanners/` — per tool: what the rule matches, common false positives, suppression syntax, re-scan command
- `references/sink-sanitizer-matrix.md` — dangerous calls → correct control → controls that look right but aren't
- `references/templates.md` — risk acceptance, secret record, fix record (for commit/PR text)
- `scripts/normalize.py` — optional: merge many scanner output files into one list when working through a whole report
- `examples/example-reports.md` — two complete reports (a true positive with fix, a false positive with suppression)
- `references/validation-results.md` — how accurate this method was on benchmark apps, and known gaps
