---
name: sca-triage
description: Analyse ONE vulnerable open-source dependency finding at a time (a CVE/GHSA/Snyk ID in a package and version) and give whether it is a direct or transitive dependency, the full dependency path, whether the vulnerable code is reachable, a verdict, and exact remediation and fix details with SEC-FIX tracking. Works for findings from Snyk Open Source, Dependabot, OWASP Dependency-Track and other SBOM (CycloneDX/SPDX) scanners, npm/yarn/pnpm audit, pip-audit, OWASP Dependency-Check, Trivy, Grype, OSV-Scanner, govulncheck, bundler-audit, Mend, Black Duck and Kondukto, across npm/yarn/pnpm, pip/Poetry/uv, Maven, Gradle, Go, Bundler and NuGet. Use when the user opens the manifest/lockfile/SBOM or names a vulnerable package and asks to triage, fix, upgrade, or explain it, or runs /sca-triage ($sca-triage in Codex).
argument-hint: "<scanner> <vuln ID> <package>@<version>   e.g. npm-audit GHSA-hrpp-h998-j3pp qs@6.7.0"
---

# One dependency finding → remediation and fix details

The user's process:
1. They pick **one** finding from their scanner report and open the project's manifest or lockfile.
2. They run this skill, e.g. `/sca-triage snyk SNYK-JS-QS-3153490 qs@6.7.0` (Claude Code) or `$sca-triage …` (Codex).
3. They expect a **Dependency Finding Report**, then decide whether to apply the fix.

The finding is whatever the user wrote with the command or in their message. If the text "$ARGUMENTS" appears literally, ignore it and use the user's message.

## Step 0 — Pin down the finding (don't guess)
Collect: **scanner** (and whether it scanned the source tree or an **SBOM file**), **vulnerability ID** (CVE / GHSA / PYSEC / SNYK-… / OSV), **package name**, **installed version**, and which **project/manifest** (monorepos have several). Use the user's text, then the open file, then the conversation. If the package or version is missing, ask **one** short question and stop until answered.

## Step 1 — Gather the raw facts
**Finding came from an SBOM** (Dependency-Track, `trivy sbom`, `grype sbom:`, `osv-scanner --sbom`)? Follow `references/sbom.md` first: confirm presence and get the path with `scripts/sbom_path.py`, check the SBOM matches the current commit, then continue below in the source repository for reachability and the fix. Without the source repo, the verdict is provisional.

1. **Lockfile is the truth, not the manifest.** Find the lockfile (`package-lock.json`, `yarn.lock`, `pnpm-lock.yaml`, `poetry.lock`, `uv.lock`, `requirements*.txt` with pins, `Pipfile.lock`, `go.sum`/`go.mod`, `Gemfile.lock`, `packages.lock.json`, Maven/Gradle resolved tree). Confirm the vulnerable version is **actually resolved** there. If it isn't, the finding may be stale or a false match.
2. **Direct or transitive, and every path.** Run the ecosystem's "why" command from `references/ecosystems.md` (e.g. `npm explain qs`, `mvn dependency:tree -Dincludes=…`, `go mod why -m …`, `pipdeptree -r -p …`). Record **all** paths: the same package often arrives through several parents, and the fix must cover every one. Note how each parent constrains it (exact pin `6.7.0` vs range `^6.7.0`). An exact pin means a reinstall can never pick up the fix.
3. **Scope.** Runtime/production, or dev/test/build-only (`devDependencies`, Maven `test`/`provided`, Gradle `testImplementation`, Poetry dev group)? Dev-only lowers severity; it does not by itself make the finding a false positive (build tools can still run attacker input in CI).
4. **The advisory itself** (GHSA / OSV / NVD / vendor). Record: affected version range, first patched version, **vulnerable function/module/config** and preconditions. Scanners often omit these.
5. **Reachability.** Search the code for use of the vulnerable function/feature (e.g. `_.template(` with user-controlled options, `qs.parse` with attacker input, `yaml.load`). For transitive packages, check whether the parent actually calls the vulnerable part (e.g. express → body-parser → `qs.parse` on every urlencoded body = reachable). Use tool reachability where it exists (`govulncheck` reports only reachable symbols). If you cannot determine it, say so; don't assume "not used".

Scanner-specific notes (output fields, common false matches, suppression syntax): `references/scanners.md`.

## Step 2 — Verdict (pick exactly one)
| Verdict | Means |
|---|---|
| **Affected (True Positive)** | Vulnerable version is resolved and the vulnerable code is reachable, or reachability is unknown |
| **Not Affected — not reachable** | Version is vulnerable but the vulnerable function/feature is not used on any path (state how you checked) |
| **Not Affected — mitigated** | Reachable, but a named control blocks it (config disables the feature, input never attacker-controlled) |
| **False Positive** | Wrong package matched (CPE mismatch), version not actually installed, already patched (distro backport), or advisory doesn't apply to this platform |
| **Risk Accepted** | Real, but fixing now is not possible/worth it (needs owner, approver, expiry) |
| **Needs Review** | Can't decide; list the exact question |

Rules:
- "Not reachable" lowers urgency; it is **not** a reason to skip a cheap, non-breaking upgrade. Recommend the upgrade anyway and say it's low-risk housekeeping.
- Reachability can change with future code. Not Affected verdicts must name what would make them Affected (e.g. "if `_.template` options ever come from user input").
- Map Not Affected verdicts to a VEX justification (`references/templates.md`) so they can be recorded in the scanner/Kondukto.

## Step 3 — Choose the fix (in this order of preference)
1. **Direct dependency:** upgrade it to the lowest version that fixes **all** advisories on it, ideally within the same major version. Check the changelog for breaking changes; flag a major-version jump.
2. **Transitive dependency — upgrade the parent first.** Find the lowest version of the *direct* dependency whose resolved tree contains a patched version. This usually fixes several transitive advisories at once.
   *(Tested: overriding only `qs` under express 4.17.1 left 7 of 8 advisories open; upgrading express to 4.22.3 fixed all 7 transitive ones.)*
3. **Transitive with no fixed parent release:** force the version with the ecosystem's override mechanism (npm `overrides`, yarn `resolutions`, pnpm `pnpm.overrides`, Maven `<dependencyManagement>`, Gradle `constraints`, `go get pkg@ver`, uv `override-dependencies`, NuGet direct `PackageReference` or central transitive pinning). Syntax per ecosystem: `references/ecosystems.md`. Overrides force a version the parent wasn't tested with: run its tests, and add a removal note ("remove when <parent> ≥ X").
   - Some ecosystems **refuse** an override that conflicts with the parent's range (pip: `ResolutionImpossible`, tested with requests 2.25.0 + idna 3.7). Then the parent upgrade is the only fix.
4. **No fix exists at all:** replace the package, remove the feature that needs it, apply a code-level mitigation, or go to Risk Accepted.

Fix rules:
- Cover **every path** found in Step 1; verify none still resolves the old version (multiple copies are common in npm).
- Change the **manifest** and regenerate the **lockfile** with the package manager. Never hand-edit a lockfile.
- Keep behaviour working: run the project's tests/build; for major upgrades list the breaking changes that touch this code.

## Step 4 — Write the Dependency Finding Report (always this layout)

```
═══ DEPENDENCY FINDING REPORT ════════════════════════════════
Finding   : <vuln ID> (<aliases>)   Scanner: <tool>
Package   : <name>@<installed version>   Ecosystem: <npm/pip/maven/...>
Type      : DIRECT | TRANSITIVE (depth <n>)      Scope: runtime | dev/test only
Verdict   : AFFECTED | NOT AFFECTED (not reachable / mitigated) | FALSE POSITIVE | RISK ACCEPTED | NEEDS REVIEW
Severity  : scanner <x> → adjusted <y>  (why: reachability / scope / exposure)

VULNERABILITY
  <one sentence: what the flaw is and the precondition, from the advisory>
  Affected: <range>   Patched: <first fixed version>   Advisory: <URL>

DEPENDENCY PATH(S)                         ← from <exact command run>
  1. <root> → <direct>@<v> → ... → <package>@<v>   (constraint: "<pin or range>")
  2. ...                                           (every path)

REACHABILITY
  Vulnerable part: <function / feature / config>
  Used by your code: yes/no/unknown — <file:line evidence or search done>
  Used via parent  : yes/no/unknown — <how the parent uses it>

REMEDIATION
  Recommended: <upgrade direct X to Y | upgrade parent P to V | override | replace>
  Why this option: <covers all paths / fixes N advisories / no breaking change>
  Alternatives considered: <option → why not>
  Breaking changes / risk: <none known | list>

FIX DETAILS
  SEC-FIX01  <manifest file>
    Before : <line(s)>
    After  : <line(s)>
    Comment: <where the tracking note goes — see "Tracking" below>
  SEC-FIX02  <lockfile>  regenerated by: <exact command>   (never hand-edited)
  SEC-FIX03  ... (each further change)

VERIFY
  Resolved : <why/ls command>   → only <package>@<fixed> remains on every path
  Re-scan  : <same scanner command>   → <vuln ID> no longer reported
  Tests    : <project test/build command>   → passes
  SBOM     : (if the finding came from an SBOM) regenerate it from the fixed code and re-scan → clean
═══════════════════════════════════════════════════════════════
```

Section changes by verdict:
- **Not Affected / False Positive:** replace REMEDIATION/FIX DETAILS with **JUSTIFICATION** (evidence, VEX justification code, what would make it Affected) and **SUPPRESSION** — the scanner's native ignore entry scoped to this vuln ID **and** package, with reason and expiry (syntax in `references/scanners.md`), plus "mark as not affected in Kondukto/Snyk/Dependabot" if used. Still mention the cheap upgrade if one exists.
- **Risk Accepted:** use the risk-acceptance record in `references/templates.md`.
- **Needs Review:** list the exact questions; no fix yet.

### Tracking (SEC-FIX comments)
Put `SEC-FIXnn <vuln ID>: <what changed>` as a comment next to the changed line **where the file format allows comments**: `pom.xml`/`.csproj` `<!-- -->`, `build.gradle(.kts)` `//`, `requirements.txt`/`pyproject.toml`/`Gemfile` `#`, `go.mod` `//`.
`package.json` and lockfiles **cannot contain comments**. Record those SEC-FIX entries in the commit message and the saved report instead, and say so in the report. For overrides add the removal condition ("remove when express ≥ 4.22.3").

## Step 5 — Ask before changing anything
End with exactly:

> **Apply this fix?** Reply **yes** to apply the SEC-FIX changes, **suppress** to add the ignore entry instead, or **no** to leave everything unchanged.

On **yes**:
1. Edit the manifest(s) only as listed, with tracking comments where allowed.
2. Regenerate the lockfile with the package manager command shown.
3. Run the VERIFY commands (why/ls, re-scan, tests) and report the **real** output, or say which couldn't run (e.g. no network, tool not installed).
4. Save the report to `security-scans/<vuln-ID>-<package>.md` (create the folder) and tell the user the path. Code changes can be reviewed in VS Code's Source Control panel.

## References
- `references/ecosystems.md`: per package manager: lockfile, "why" command, how to upgrade direct/parent, override syntax, comment syntax, verify commands
- `references/scanners.md`: per SCA tool: run command, output fields, common false matches, ignore syntax
- `references/sbom.md`: SBOM-based findings: what an SBOM can/can't tell you, Trivy/Grype/OSV on SBOMs, Dependency-Track analysis states
- `scripts/sbom_path.py`: direct vs transitive and every path for a package in a CycloneDX/SPDX SBOM
- `references/templates.md`: VEX justifications, risk acceptance record, commit message
- `examples/example-reports.md`: a transitive finding (qs via express) and a direct one (lodash), both tested
