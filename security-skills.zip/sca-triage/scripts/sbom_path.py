#!/usr/bin/env python3
"""Show whether a package in an SBOM is direct or transitive, and every path to it.

Usage: sbom_path.py SBOM.json PACKAGE[@VERSION] [--max-paths N]

Reads CycloneDX JSON (components + dependencies) and SPDX JSON
(packages + relationships). Many SBOMs (e.g. from container images) have no
dependency graph at all; the script says so instead of guessing, and the path
must then come from the project's lockfile.
"""
import json
import sys
from collections import defaultdict


def load_cyclonedx(d):
    root = (d.get("metadata", {}).get("component") or {}).get("bom-ref")
    comps = {}
    for c in d.get("components", []) or []:
        ref = c.get("bom-ref") or c.get("purl") or f"{c.get('name')}@{c.get('version')}"
        comps[ref] = {"name": c.get("name"), "version": c.get("version"),
                      "purl": c.get("purl"), "scope": c.get("scope")}
    edges = defaultdict(list)
    for dep in d.get("dependencies", []) or []:
        for child in dep.get("dependsOn", []) or []:
            edges[dep["ref"]].append(child)
    return root, comps, edges


def load_spdx(d):
    comps, edges = {}, defaultdict(list)
    for p in d.get("packages", []) or []:
        purl = next((r.get("referenceLocator") for r in p.get("externalRefs", []) or []
                     if r.get("referenceType") == "purl"), None)
        comps[p["SPDXID"]] = {"name": p.get("name"), "version": p.get("versionInfo"),
                              "purl": purl, "scope": None}
    root = None
    for r in d.get("relationships", []) or []:
        a, t, b = r.get("spdxElementId"), r.get("relationshipType"), r.get("relatedSpdxElement")
        if t == "DESCRIBES":
            root = b
        elif t in ("DEPENDS_ON", "CONTAINS"):
            edges[a].append(b)
        elif t in ("DEPENDENCY_OF", "DEV_DEPENDENCY_OF", "OPTIONAL_DEPENDENCY_OF",
                   "BUILD_DEPENDENCY_OF", "TEST_DEPENDENCY_OF", "RUNTIME_DEPENDENCY_OF"):
            edges[b].append(a)  # a is a dependency of b  ->  b depends on a
            if t != "DEPENDENCY_OF" and a in comps:
                comps[a]["scope"] = t.replace("_DEPENDENCY_OF", "").lower()
    root = root or (d.get("documentDescribes") or [None])[0]
    return root, comps, edges


def label(ref, comps):
    c = comps.get(ref)
    return f"{c['name']}@{c['version']}" if c else ref


def main():
    args = sys.argv[1:]
    max_paths = 20
    if "--max-paths" in args:
        i = args.index("--max-paths")
        max_paths = int(args[i + 1])
        del args[i:i + 2]
    if len(args) != 2:
        sys.exit(__doc__)
    d = json.load(open(args[0], encoding="utf-8"))
    want = args[1]
    name, _, version = want.rpartition("@") if "@" in want.lstrip("@") else (want, "", "")
    if not name:  # "pkg" without version
        name, version = want, ""
    if "bomFormat" in d or "components" in d:
        fmt, (root, comps, edges) = "CycloneDX", load_cyclonedx(d)
    elif "spdxVersion" in d:
        fmt, (root, comps, edges) = "SPDX", load_spdx(d)
    else:
        sys.exit("Unrecognized SBOM: expected CycloneDX or SPDX JSON")

    targets = [r for r, c in comps.items()
               if c["name"] == name and (not version or c["version"] == version)]
    print(f"SBOM: {fmt}, {len(comps)} components, graph edges: {sum(len(v) for v in edges.values())}")
    if not targets:
        print(f"'{want}' is NOT in this SBOM. If a scanner reported it, the finding may be stale or a false match.")
        return
    if not edges:
        print("This SBOM has no dependency graph, so direct/transitive can't be determined from it.")
        print("Use the project's lockfile and its 'why' command (see references/ecosystems.md).")
        for t in targets:
            print(f"  present: {label(t, comps)}  purl={comps[t]['purl']}")
        return
    if not root:
        print("SBOM names no root component; paths start from components nothing depends on.")
        children = {c for v in edges.values() for c in v}
        roots = [r for r in edges if r not in children]
    else:
        roots = [root]

    parents = defaultdict(list)
    for a, kids in edges.items():
        for k in kids:
            parents[k].append(a)

    for t in targets:
        paths, stack = [], [[t]]
        while stack and len(paths) < max_paths:
            p = stack.pop()
            head = p[-1]
            if head in roots:
                paths.append(list(reversed(p)))
                continue
            for par in parents.get(head, []):
                if par not in p:  # avoid cycles
                    stack.append(p + [par])
        c = comps[t]
        if not paths:
            kind = "UNREACHABLE FROM ROOT (graph incomplete; check the lockfile)"
        else:
            kind = "DIRECT" if any(len(p) == 2 for p in paths) else "TRANSITIVE"
            if any(len(p) == 2 for p in paths) and any(len(p) > 2 for p in paths):
                kind = "DIRECT and also TRANSITIVE"
        print(f"\n{label(t, comps)}  purl={c['purl']}  scope={c['scope'] or 'n/a'}")
        print(f"Type: {kind}" + (f"   depth: {min(len(p) for p in paths) - 1}" if paths else ""))
        print("Direct parents: " + (", ".join(label(p, comps) for p in parents.get(t, [])) or "none"))
        for i, p in enumerate(sorted(paths, key=len), 1):
            print(f"  {i}. " + " -> ".join(label(x, comps) for x in p))
        if len(paths) >= max_paths:
            print(f"  ... stopped at {max_paths} paths (use --max-paths N)")


if __name__ == "__main__":
    main()
