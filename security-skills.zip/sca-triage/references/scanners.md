# SCA scanners: output, false matches, ignore syntax

Findings that came from scanning an SBOM file: see `sbom.md`.

General rules:
- One vulnerability often has several IDs (CVE, GHSA, PYSEC, SNYK-…, OSV). List the aliases in the report and ignore by the ID the scanner uses.
- Ignore entries must name the **vulnerability and the package**, carry a **reason** and an **expiry** where the tool supports one. Never ignore a whole package or severity level.
- If findings flow through **Kondukto** (or Snyk/Dependabot UI), record the verdict there too so a re-scan doesn't reopen it, and reference the Kondukto ID in any file-based ignore.

## npm audit
- Run: `npm audit --json` (`--omit=dev` to see production only).
- Fields: `vulnerabilities.<name>` → `isDirect`, `range`, `via` (dicts = advisories on this package; strings = it is flagged *because of* a vulnerable child), `effects`, `fixAvailable` (`{name, version, isSemVerMajor}` = the **direct** package to change).
- Tested: `fixAvailable` on transitive `qs` pointed at `express@4.22.3`, the parent upgrade, which matched the best fix.
- Ignore: npm has no ignore file. Use the CI wrapper's allowlist (e.g. `audit-ci` `allowlist`), record in Kondukto, and prefer fixing.

## pnpm / Yarn audit
- `pnpm audit --json` · ignore in `package.json`: `"pnpm": { "auditConfig": { "ignoreGhsas": ["GHSA-…"] } }` (older: `ignoreCves`).
- Yarn 4: `yarn npm audit --json` · ignore: `npmAuditIgnoreAdvisories` in `.yarnrc.yml`.

## pip-audit
- Run: `pip-audit -r requirements.txt -f json -o pip-audit.json`. Without `-r` it audits the **current environment**, including unrelated tools installed there.
- Tested: the same ID can appear twice in output; de-duplicate by `id` + package.
- Fields: `dependencies[].name/version/vulns[].id/fix_versions/aliases`. It doesn't show the path; use `pipdeptree -r -p <pkg>`.
- Ignore: `pip-audit --ignore-vuln PYSEC-2024-60` (put it in the CI command with a comment and expiry date).

## Snyk Open Source
- Run: `snyk test --json > snyk-oss.json` (or `--sarif`).
- Fields: `vulnerabilities[]` → `id` (SNYK-…), `packageName`, `version`, **`from`** (full path: root → … → package), **`upgradePath`** (the direct-dependency version that fixes it; `false` entries = no change at that level), `isUpgradable`, `isPatchable`, `semver.vulnerable`, `identifiers.CVE/CWE`.
- Ignore: `snyk ignore --id=SNYK-JS-QS-3153490 --expiry=2027-01-31 --reason="SEC-123 not reachable: …"` (writes `.snyk`; add `--path='express > qs'` to scope it to one path).

## GitHub Dependabot
- Alerts: repo **Security → Dependabot**, or `gh api repos/OWNER/REPO/dependabot/alerts`.
- Fields: `dependency.package`, `dependency.manifest_path`, `dependency.scope` (runtime/development), `security_advisory`, `security_vulnerability.first_patched_version`.
- Dismiss with a reason: `fix_started`, `inaccurate`, `no_bandwidth`, `not_used`, `tolerable_risk`, plus a comment linking the report.

## OWASP Dependency-Check
- Run: `dependency-check --scan . --format JSON --out .`
- Matches libraries to vulnerabilities by **CPE**, which is the main source of false positives (a library matched to an unrelated product with a similar name, or a shaded/renamed jar). Check `evidenceCollected` and the CPE before trusting a finding.
- Ignore (`dependency-check-suppressions.xml`):
```xml
<suppressions xmlns="https://jeremylong.github.io/DependencyCheck/dependency-suppression.1.3.xsd">
  <suppress until="2027-01-31Z">
    <notes>SEC-123 false CPE match: library is X, advisory is for product Y</notes>
    <packageUrl regex="true">^pkg:maven/org\.example/lib@.*$</packageUrl>
    <cve>CVE-2021-12345</cve>
  </suppress>
</suppressions>
```

## Trivy (tested 0.74.0 on an SBOM; see `sbom.md`)
- Run: `trivy fs --scanners vuln --format json -o trivy.json .`, `trivy image …`, or `trivy sbom sbom.json`.
- Reports CVE IDs (npm/GitHub use GHSA for the same flaw). `FixedVersion` may list several backport lines; to clear every advisory take the highest fix on your line. Add `--dependency-tree` to show which direct dependency pulls a package in, for supported lockfiles.
- Fields: `Results[].Target`, `Vulnerabilities[]` → `VulnerabilityID`, `PkgName`, `InstalledVersion`, `FixedVersion`, `PkgIdentifier.PURL`.
- OS packages in images: Linux distros **backport** fixes without changing the upstream version. Trust the distro's fixed version, not the upstream one, before calling it vulnerable.
- Ignore (all three tested): `.trivyignore` line `CVE-2022-24999 exp:2027-01-31` (expired entries stop applying); `.trivyignore.yaml` with `id`, `purls`, `statement`, `expired_at`; or `--vex vex.json` (product `@id` must equal the SBOM root purl).

## Grype
- Run: `grype dir:. -o json > grype.json` (`--only-fixed` hides unfixable ones).
- Ignore (`.grype.yaml`), scope to package:
```yaml
ignore:
  # SEC-123 not reachable, expires 2027-01-31: re-review then
  - vulnerability: GHSA-hrpp-h998-j3pp
    package: { name: qs, version: 6.7.0, type: npm }
```
- Grype also accepts VEX documents (`--vex`).

## OSV-Scanner
- Run: `osv-scanner scan source -r . --format json` (v2) or `osv-scanner --lockfile package-lock.json` (v1).
- Ignore (`osv-scanner.toml`):
```toml
[[IgnoredVulns]]
id = "GHSA-hrpp-h998-j3pp"
ignoreUntil = 2027-01-31
reason = "SEC-123 not reachable: ..."
```

## govulncheck (Go)
- Run: `govulncheck -json ./...`. By default it reports only vulnerabilities whose vulnerable **symbols are called** from your code. That's strong reachability evidence (it shows the call stack). `-show verbose` lists imported-but-not-called ones too.
- No ignore file; record Not Affected verdicts in Kondukto / VEX.

## bundler-audit (Ruby)
- Run: `bundle exec bundle-audit check --update`.
- Ignore: `--ignore CVE-2024-1234` or `.bundler-audit.yml` → `ignore: [CVE-2024-1234]` (add a `#` comment with reason and expiry).

## Mend / Black Duck / Kondukto
- Export the finding **with its dependency path** (library hierarchy / "via" chain). Summary rows often omit transitive parents.
- Record verdicts in the platform's workflow (ignore / not affected / risk accepted) with reason, approver and expiry, and link the saved report.

## OWASP Dependency-Track (SBOM platform)
See `sbom.md`: upload/finding API, the Dependency Graph view, and how each verdict maps to an Analysis state, justification and suppression.
