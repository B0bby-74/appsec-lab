# Templates

## VEX justification (for Not Affected / False Positive verdicts)
Use the standard justification codes (CISA / OpenVEX) so the decision can be recorded in scanners that read VEX (Trivy, Grype) and in Kondukto:

| Verdict | VEX status | Justification |
|---|---|---|
| False positive: package not actually installed / wrong package matched | `not_affected` | `component_not_present` |
| False positive: installed build doesn't contain the vulnerable code (patched/backported) | `not_affected` | `vulnerable_code_not_present` |
| Not affected: vulnerable function never called | `not_affected` | `vulnerable_code_not_in_execute_path` |
| Not affected: called, but input can't come from an attacker | `not_affected` | `vulnerable_code_cannot_be_controlled_by_adversary` |
| Not affected: a control blocks it (config/feature off, validation) | `not_affected` | `inline_mitigations_already_exist` |
| Fix applied | `fixed` | n/a |
| Being fixed / risk accepted | `affected` | (add `action_statement`) |

OpenVEX statement (save as e.g. `security-scans/vex.json`). **The product `@id` must exactly equal your SBOM's root purl** (`metadata.component.purl`), or scanners like Trivy silently ignore the statement (tested):
```json
{
  "@context": "https://openvex.dev/ns/v0.2.0",
  "@id": "https://example.invalid/vex/<vuln-id>-<package>",
  "author": "<team>",
  "timestamp": "<ISO date>",
  "version": 1,
  "statements": [{
    "vulnerability": { "name": "<GHSA/CVE id>" },
    "products": [{ "@id": "pkg:<ecosystem>/<your-app>@<version>",
                   "subcomponents": [{ "@id": "pkg:npm/qs@6.7.0" }] }],
    "status": "not_affected",
    "justification": "vulnerable_code_not_in_execute_path",
    "impact_statement": "<one sentence with file:line evidence; what would make it affected>"
  }]
}
```
`products[].@id` = your app's purl (the SBOM root); `subcomponents[].@id` = the vulnerable package's purl. This template was tested with `trivy sbom --vex`.

## Risk acceptance record
```
Record ID:             RA-<yyyy>-<nnn>
Finding:               <vuln ID> in <package>@<version> (<direct|transitive via …>), adjusted severity <y>
Why not fixing now:    <no fixed version | breaking major upgrade needs <work> | parent unmaintained>
Compensating controls: <WAF rule, feature disabled, input validation at file:line, network restriction>
Residual risk:         <what an attacker can still do>
Planned fix:           <upgrade X when Y is released / replace package by <date>>
Risk owner:            <name, role>
Approver:              <name, role>  (must differ from owner)
Accepted on / Expires: <date> / <date>  (≤90 days High/Critical, ≤180 Medium, ≤365 Low)
Ignore entry:          <file + exact entry, with the same expiry>
Status:                REQUESTED | APPROVED | EXPIRED
```

## Commit message (use for package.json / lockfile changes that can't hold comments)
```
fix(deps): <vuln ID> <package> <old> -> <new> (SEC-FIX01..nn)

SEC-FIX01 <manifest>: <direct|parent> <name> <old> -> <new>
SEC-FIX02 <lockfile>: regenerated with `<command>`
Path(s) fixed: <root> > <parent> > <package>
Also fixes: <other advisory IDs closed by the same change>
Verified: `<why command>` shows only <package>@<fixed>; `<scanner>` no longer reports <vuln ID>; `<tests>` pass
Remove override when: <condition, if an override was used>
```
