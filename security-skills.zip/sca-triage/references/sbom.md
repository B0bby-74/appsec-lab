# Findings from an SBOM (CycloneDX / SPDX)

Use this when the finding comes from a tool that scanned an **SBOM file**, not the source tree: OWASP Dependency-Track, `trivy sbom`, `grype sbom:`, `osv-scanner --sbom`, or a vendor platform that ingests SBOMs (Kondukto, Snyk, Mend, Black Duck…).

## What an SBOM can and can't tell you
| Question | From the SBOM? |
|---|---|
| Is package@version present in the build? | Yes: `components` (CycloneDX) / `packages` (SPDX) |
| Direct or transitive, and every path | **Only if the SBOM has a dependency graph**: CycloneDX `dependencies[]`, SPDX `relationships` (DEPENDS_ON / DEPENDENCY_OF). Many SBOMs, especially from container images, have none |
| Dev/test-only? | Sometimes: SPDX `DEV_DEPENDENCY_OF`/`TEST_DEPENDENCY_OF`; CycloneDX `scope` is usually just `required`, so don't rely on it |
| Is the vulnerable code reachable? | **No.** An SBOM lists packages, not code. You need the source repository |
| How to fix it? | **No.** The fix is made in the project's manifest/lockfile (`references/ecosystems.md`); the SBOM is regenerated afterwards |

So with an SBOM-only finding: identify presence and path from the SBOM, then **go to the source repo** for reachability and the fix. If the repo isn't available, the verdict is provisional ("Affected — reachability unknown") and the report must say what's missing.

## Get the path from the SBOM
```bash
python3 <skill-dir>/scripts/sbom_path.py sbom.json qs@6.7.0
```
Prints DIRECT / TRANSITIVE, depth, direct parents and every path from the root (tested on CycloneDX 1.5 and SPDX 2.3 from `npm sbom`; the result matched `npm explain`). If the SBOM has no graph it says so: then use the lockfile's "why" command. If the package isn't in the SBOM at all, the finding may come from an older SBOM or a false match.

## Check the SBOM matches the code you're fixing
- Compare the SBOM's root component (`metadata.component` name/version/purl in CycloneDX; the `DESCRIBES` target in SPDX) and its timestamp with the commit you're on.
- After fixing, **regenerate the SBOM** from the fixed code (`npm sbom --sbom-format cyclonedx`, `syft dir:. -o cyclonedx-json`, `trivy fs --format cyclonedx .`, `cdxgen`, Maven/Gradle CycloneDX plugins) and re-scan it. Re-scanning the old SBOM will still show the finding.

## Scanners that read SBOMs
### Trivy: `trivy sbom` (tested, Trivy 0.74.0)
```bash
trivy sbom --format json -o trivy-sbom.json sbom.json
```
- Reports **CVE IDs** where npm audit/GitHub report GHSA IDs (`CVE-2022-24999` = `GHSA-hrpp-h998-j3pp`). Match on aliases.
- `FixedVersion` can list several backport lines (`6.10.3, 6.9.7, 6.8.3, 6.7.3…`). To fix **every** advisory on the package, take the highest per-advisory fix on your line (qs needed 6.16.1, not 6.7.3).
- Suppression, all tested:
  - `.trivyignore`: `CVE-2022-24999 exp:2027-01-31`. After the expiry date the finding **comes back** (verified).
  - `.trivyignore.yaml` scoped to one package: `id`, `purls: [pkg:npm/lodash@4.17.20]`, `statement`, `expired_at`.
  - OpenVEX via `--vex vex.json` (template in `templates.md`). **The product `@id` must exactly equal the SBOM root purl** (`metadata.component.purl`). With a different purl Trivy silently ignores the VEX and keeps reporting the finding (verified).

### Grype: `grype sbom:./sbom.json` (not tested here)
`grype sbom:./sbom.json -o json`; ignore rules in `.grype.yaml` (see `scanners.md`); `--vex vex.json` for OpenVEX.

### OSV-Scanner (not tested here)
v1: `osv-scanner --sbom=sbom.json --format json` · v2: `osv-scanner scan --sbom sbom.json`. Ignores in `osv-scanner.toml` (`[[IgnoredVulns]]` with `ignoreUntil` and `reason`).

### OWASP Dependency-Track (not tested here: needs a running server)
- Upload: `PUT /api/v1/bom` (multipart: `projectName`, `projectVersion`, `autoCreate=true`, `bom=@sbom.json`) with header `X-Api-Key`.
- Findings: `GET /api/v1/finding/project/{projectUuid}` returns `component` (name, version, purl, uuid), `vulnerability` (vulnId, source, severity, aliases), `analysis` (state, isSuppressed). Or export from the UI: project → Audit Vulnerabilities.
- Path: open the component → **Dependency Graph** (only shown when the uploaded SBOM had `dependencies`), or run `sbom_path.py` on the same SBOM.
- Record the verdict in the finding's **Analysis** (UI) or `PUT /api/v1/analysis`:

| Skill verdict | Analysis state | Justification | Suppress |
|---|---|---|---|
| Affected (fixing) | `EXPLOITABLE` | n/a | no (response `UPDATE`) |
| Not affected: not reachable | `NOT_AFFECTED` | `CODE_NOT_REACHABLE` | yes |
| Not affected: mitigated | `NOT_AFFECTED` | `PROTECTED_BY_MITIGATING_CONTROL` / `REQUIRES_CONFIGURATION` | yes |
| False positive | `FALSE_POSITIVE` | `CODE_NOT_PRESENT` (if applicable) | yes |
| Risk accepted | `EXPLOITABLE` | n/a | response `WILL_NOT_FIX` / `CAN_NOT_FIX`, details = RA record ID + expiry |
| Needs review | `IN_TRIAGE` | n/a | no |
| Fixed (after new SBOM upload) | `RESOLVED` (or the finding disappears) | n/a | n/a |

Put the report's justification text and the saved report path in the analysis **details/comment**. Dependency-Track can also import CycloneDX VEX (`PUT /api/v1/vex`).

## Report additions for SBOM findings
Add to the report header:
```
SBOM      : <file> (<CycloneDX x.y | SPDX x.y>), root <name@version>, generated <timestamp>
Graph     : present | absent (path taken from <lockfile command> instead)
Source    : repo available at <commit> | NOT available → reachability unknown, verdict provisional
```
and in VERIFY add: `Regenerated SBOM: <command> → <package>@<fixed> present, old version absent; re-scan clean`.
