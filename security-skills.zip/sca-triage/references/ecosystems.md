# Ecosystems: find the path, fix direct vs transitive, verify

Always run commands from the directory that holds the manifest. In monorepos/workspaces, find which package's manifest pulls the dependency in.

---
## npm (`package.json` + `package-lock.json`)
**Why / path** (needs `node_modules`: run `npm ci` first; on a lockfile-only checkout `npm explain` prints nothing):
```bash
npm explain qs           # every path, with the constraint each parent declares
npm ls qs --all          # tree view; "deduped"/"overridden" markers
npm view express@4.22.3 dependencies   # what a candidate parent version would pull in
```
**Direct upgrade:** `npm install lodash@4.18.1 --save-exact` (or keep the project's range style).
**Parent upgrade (transitive):** `npm install express@4.22.3`. Check with `npm ls qs --all` that every path now resolves the fixed version.
**Override (only if no fixed parent):** in `package.json` (npm ≥ 8.3):
```json
"overrides": { "qs": "6.17.1" }
"overrides": { "express": { "qs": "6.17.1" } }      // scoped to one parent
```
then `npm install`. If the package is *also* a direct dependency, the override must match it (or use `"$qs"`).
**Avoid blindly running** `npm audit fix --force`: it can jump major versions.
**Comments:** `package.json` and `package-lock.json` can't hold comments. Put SEC-FIX notes in the commit message and the report.
**Verify:** `npm ls qs --all` (no old version anywhere) · `npm audit --omit=dev` · `npm test`.

## Yarn
- v1 (classic): `yarn why qs` · `yarn upgrade express@4.22.3` · override: `"resolutions": { "qs": "6.17.1" }` then `yarn install`.
- v2+ (berry): `yarn why qs` · `yarn up express@4.22.3` · same `"resolutions"` field.
- Verify: `yarn why qs` · `yarn npm audit` (berry) / `yarn audit` (v1).

## pnpm
`pnpm why qs` · `pnpm update express@4.22.3` · override in `package.json`:
```json
"pnpm": { "overrides": { "qs": "6.17.1", "express>qs": "6.17.1" } }
```
(newer pnpm also accepts `overrides:` in `pnpm-workspace.yaml`). Verify: `pnpm why qs` · `pnpm audit`.

---
## pip (`requirements.txt`, constraints files)
**Why / path** (run inside the project's own virtualenv: `pipdeptree` also lists its *own* dependencies, so ignore entries under pipdeptree/nab*):
```bash
pip install pipdeptree && pipdeptree -r -p idna      # reverse tree: who requires idna, with ranges
```
**Direct upgrade:** change the pin in `requirements.txt` (`requests==2.33.0  # SEC-FIX01 PYSEC-2023-74: ...`).
**Transitive:** upgrade the parent first. Pinning the transitive package (add `idna==3.7` to requirements, or a constraints file `-c constraints.txt`) only works if it fits every parent's range. pip refuses otherwise (**tested:** `requests==2.25.0` + `idna==3.7` → `ResolutionImpossible`, because requests 2.25 requires `idna<3`).
**Verify:** fresh venv `pip install -r requirements.txt` · `pipdeptree -r -p idna` · `pip-audit -r requirements.txt` · tests.

## Poetry (`pyproject.toml` + `poetry.lock`)
`poetry show --tree` (find the package under its parents) · `poetry show idna` · direct/parent: `poetry add requests@^2.33.0` · transitive pin: `poetry add "idna>=3.7"` (makes it a direct constraint; note why in a `#` comment) · then `poetry lock` · verify `poetry show --tree`, re-scan.

## uv (`pyproject.toml` + `uv.lock`)
`uv tree --invert --package idna` · parent: edit the requirement, `uv lock --upgrade-package requests` · override:
```toml
[tool.uv]
override-dependencies = ["idna>=3.7"]   # SEC-FIX01 PYSEC-2024-60: remove when requests pulls >=3.7
```
then `uv lock` · verify `uv tree --invert --package idna`.

---
## Maven (`pom.xml`)
**Why / path:**
```bash
mvn dependency:tree -Dincludes=com.fasterxml.jackson.core:jackson-databind -Dverbose
```
Maven picks the **nearest** declaration in the tree, not the highest version.
**Direct upgrade:** change `<version>` (or the version property).
**Transitive:** upgrade the parent dependency or BOM first (for Spring Boot etc. override the BOM's version property, e.g. `<jackson-bom.version>`). Otherwise pin in `<dependencyManagement>`:
```xml
<dependencyManagement><dependencies>
  <!-- SEC-FIX01 CVE-2020-36518: pin transitive jackson-databind; remove when parent ships >= 2.13.2.1 -->
  <dependency><groupId>com.fasterxml.jackson.core</groupId><artifactId>jackson-databind</artifactId><version>2.13.2.1</version></dependency>
</dependencies></dependencyManagement>
```
**Verify:** `mvn dependency:tree -Dincludes=…` · `mvn -q verify` · re-scan.

## Gradle (`build.gradle` / `build.gradle.kts`)
**Why / path:** `./gradlew dependencyInsight --dependency jackson-databind --configuration runtimeClasspath`
**Transitive pin with built-in tracking text:**
```kotlin
dependencies {
  constraints {
    implementation("com.fasterxml.jackson.core:jackson-databind:2.13.2.1") {
      because("SEC-FIX01 CVE-2020-36518: transitive via <parent>; remove when parent >= X")
    }
  }
}
```
If dependency locking is on, refresh with `./gradlew dependencies --write-locks`. Verify with `dependencyInsight` + tests.

---
## Go (`go.mod` + `go.sum`)
**Why / path:** `go mod why -m golang.org/x/net` · `go mod graph | grep 'golang.org/x/net@'`
**Reachability (best available):** `govulncheck ./...` reports only vulnerabilities whose vulnerable symbols your code actually calls; `govulncheck -show verbose ./...` also lists module-level ones not called.
**Fix (direct or transitive, same command):** Go uses minimal version selection, so raising the minimum works without an override:
```bash
go get golang.org/x/net@v0.23.0 && go mod tidy
```
Comment: `// SEC-FIX01 CVE-…` on the line above the `require` entry; check it survives `go mod tidy`.
**Verify:** `go list -m golang.org/x/net` · `govulncheck ./...` · `go test ./...`.

## Ruby / Bundler (`Gemfile` + `Gemfile.lock`)
**Why / path:** in `Gemfile.lock` each gem lists its dependencies indented beneath it; search for the vulnerable gem's name under other gems. `bundle viz` draws the graph.
**Fix:** `bundle update --conservative <gem>` (moves only that gem) · parent: `bundle update --conservative <parent>` · transitive pin: add `gem "nokogiri", ">= 1.16.5"  # SEC-FIX01 CVE-…` to `Gemfile`, then `bundle install`.
**Verify:** `bundle exec bundle-audit check --update` · tests.

## .NET / NuGet (`*.csproj`, `packages.lock.json`)
**Why / path:** `dotnet list package --vulnerable --include-transitive` · `dotnet nuget why <project> <package>` (needs a recent .NET 8.0.4xx+ SDK).
**Transitive fix:** add a direct reference to the fixed version:
```xml
<!-- SEC-FIX01 CVE-…: pin transitive System.Text.Json; remove when parent upgraded -->
<PackageReference Include="System.Text.Json" Version="8.0.5" />
```
or with Central Package Management set `<CentralPackageTransitivePinningEnabled>true</CentralPackageTransitivePinningEnabled>` and the version in `Directory.Packages.props`. Lockfile: `dotnet restore --force-evaluate`.
**Verify:** `dotnet list package --vulnerable --include-transitive` · `dotnet test`.

## PHP / Composer (`composer.json` + `composer.lock`)
`composer why vendor/pkg` · `composer update vendor/pkg --with-dependencies` · parent: `composer require vendor/parent:^X` · verify `composer audit`.
