#!/usr/bin/env python3
"""Normalize scanner output into one finding list.

Usage: normalize.py [--root DIR] FILE [FILE ...] > findings.json

Absolute paths under DIR (default: current dir) are made relative so the
same location reported by different tools groups together. Run it from the
repository root, or pass --root.

Auto-detects: SARIF (any tool), Bandit JSON, gosec JSON, Brakeman JSON,
ESLint JSON, Semgrep JSON, njsscan JSON, TruffleHog NDJSON, SpotBugs XML.
Never emits secret values (TruffleHog Raw is dropped).
"""
import json
import os
import re
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict

RELATED_LINES = 5
ROOT = None  # set by --root DIR

# SpotBugs/FindSecBugs XML often carries no CWE at all; map common bug types.
# Informational types (SERVLET_PARAMETER, COOKIE_USAGE, SERVLET_HEADER...) flag
# input *sources*, not vulnerabilities, and are deliberately left unmapped.
SPOTBUGS_CWE = {
    "SQL_INJECTION_JDBC": 89, "SQL_INJECTION_SPRING_JDBC": 89, "SQL_INJECTION_JPA": 89,
    "SQL_INJECTION_HIBERNATE": 89, "SQL_INJECTION": 89,
    "SQL_NONCONSTANT_STRING_PASSED_TO_EXECUTE": 89,
    "SQL_PREPARED_STATEMENT_GENERATED_FROM_NONCONSTANT_STRING": 89,
    "COMMAND_INJECTION": 78, "XSS_SERVLET": 79, "XSS_REQUEST_WRAPPER": 79, "XSS_JSP_PRINT": 79,
    "XSS_REQUEST_PARAMETER_TO_SERVLET_WRITER": 79, "XSS_REQUEST_PARAMETER_TO_SEND_ERROR": 79,
    "PATH_TRAVERSAL_IN": 22, "PATH_TRAVERSAL_OUT": 22, "PT_RELATIVE_PATH_TRAVERSAL": 23,
    "PT_ABSOLUTE_PATH_TRAVERSAL": 36, "LDAP_INJECTION": 90, "XPATH_INJECTION": 643,
    "TRUST_BOUNDARY_VIOLATION": 501, "PREDICTABLE_RANDOM": 330, "INSECURE_COOKIE": 614,
    "HTTPONLY_COOKIE": 1004, "DES_USAGE": 327, "TDES_USAGE": 327, "CIPHER_INTEGRITY": 353,
    "STATIC_IV": 329, "PADDING_ORACLE": 696, "ECB_MODE": 327,
    "WEAK_MESSAGE_DIGEST_MD5": 328, "WEAK_MESSAGE_DIGEST_SHA1": 328,
    "HTTP_RESPONSE_SPLITTING": 113, "HRS_REQUEST_PARAMETER_TO_COOKIE": 113,
    "HRS_REQUEST_PARAMETER_TO_HTTP_HEADER": 113, "UNVALIDATED_REDIRECT": 601,
    "XXE_DOCUMENT": 611, "XXE_SAXPARSER": 611, "XXE_XMLREADER": 611, "XXE_XMLSTREAMREADER": 611,
    "OBJECT_DESERIALIZATION": 502, "SPEL_INJECTION": 94, "SCRIPT_ENGINE_INJECTION": 94,
    "HARD_CODE_PASSWORD": 798, "HARD_CODE_KEY": 321, "URLCONNECTION_SSRF_FD": 918,
}

# ESLint JSON carries no CWE. detect-object-injection is deliberately unmapped:
# it fires on any obj[var] and is not by itself a vulnerability class.
ESLINT_CWE = {
    "security/detect-eval-with-expression": 95, "security/detect-child-process": 78,
    "security/detect-non-literal-fs-filename": 22, "security/detect-non-literal-require": 829,
    "security/detect-unsafe-regex": 1333, "security/detect-non-literal-regexp": 1333,
    "security/detect-possible-timing-attacks": 208, "security/detect-pseudoRandomBytes": 338,
    "security/detect-buffer-noassert": 119, "security/detect-new-buffer": 119,
    "security/detect-disable-mustache-escape": 79,
    "security/detect-no-csrf-before-method-override": 352,
    "no-unsanitized/method": 79, "no-unsanitized/property": 79,
}


def rec(tool, rule, file, line, cwe=None, severity=None, confidence=None,
        message=None, fingerprint=None, trace=None, suppressed=False, extra=None):
    cwe_s = None
    if cwe:
        m = re.search(r"(\d+)", str(cwe))
        cwe_s = f"CWE-{m.group(1)}" if m else None
    try:
        line_i = int(str(line).split("-")[0]) if line not in (None, "") else None
    except ValueError:
        line_i = None
    file = (file or "").replace("file://", "")
    # Tools mix absolute and relative paths; make them comparable so the same
    # line from different scanners groups together. Override base with --root.
    if os.path.isabs(file):
        base = ROOT or os.getcwd()
        if os.path.commonpath([base, file]) == base:
            file = os.path.relpath(file, base)
    file = os.path.normpath(file) if file else file
    if file.startswith("./"):
        file = file[2:]
    r = {
        "tool": tool, "rule": rule, "cwe": cwe_s, "file": file, "line": line_i,
        "severity": severity, "confidence": confidence, "message": message,
        "fingerprint": fingerprint, "trace": trace or [], "suppressed": suppressed,
    }
    if extra:
        r.update(extra)
    return r


def first_cwe(v):
    if isinstance(v, list):
        v = v[0] if v else None
    if isinstance(v, dict):
        v = v.get("id")
    return v


def sarif_loc(loc):
    pl = (loc or {}).get("physicalLocation", {})
    return (pl.get("artifactLocation", {}).get("uri"),
            pl.get("region", {}).get("startLine"))


def parse_sarif(d):
    out = []
    for run in d.get("runs", []):
        tool = run.get("tool", {}).get("driver", {}).get("name", "sarif")
        rules = {}
        for r in run.get("tool", {}).get("driver", {}).get("rules", []) or []:
            rules[r.get("id")] = r
        for res in run.get("results", []):
            rid = res.get("ruleId")
            rule = rules.get(rid, {})
            props = {**rule.get("properties", {}), **res.get("properties", {})}
            cwe = props.get("cwe")
            if not cwe:
                for t in props.get("tags", []) or []:
                    if "CWE" in str(t).upper():
                        cwe = t
                        break
            f, ln = sarif_loc((res.get("locations") or [{}])[0])
            trace = []
            for cf in res.get("codeFlows", []) or []:
                for tf in cf.get("threadFlows", []) or []:
                    for step in tf.get("locations", []) or []:
                        sf, sl = sarif_loc(step.get("location"))
                        msg = step.get("location", {}).get("message", {}).get("text")
                        trace.append({"file": sf, "line": sl, "note": msg})
                    break
                break
            fp = res.get("fingerprints") or res.get("partialFingerprints")
            out.append(rec(tool, rid, f, ln, first_cwe(cwe), res.get("level"),
                           props.get("confidence") or props.get("precision"),
                           res.get("message", {}).get("text"),
                           json.dumps(fp, sort_keys=True) if fp else None,
                           trace, bool(res.get("suppressions"))))
    return out


def parse_bandit(d):
    return [rec("bandit", r.get("test_id"), r.get("filename"), r.get("line_number"),
                first_cwe(r.get("issue_cwe")), r.get("issue_severity"),
                r.get("issue_confidence"), r.get("issue_text"))
            for r in d.get("results", [])]


def parse_gosec(d):
    return [rec("gosec", r.get("rule_id"), r.get("file"), r.get("line"),
                first_cwe(r.get("cwe")), r.get("severity"), r.get("confidence"),
                r.get("details"), suppressed=bool(r.get("suppressions")))
            for r in d.get("Issues", []) or []]


def parse_brakeman(d):
    out = []
    for w in d.get("warnings", []):
        out.append(rec("brakeman", f"{w.get('check_name')}/{w.get('warning_code')}",
                       w.get("file"), w.get("line"), first_cwe(w.get("cwe_id")),
                       w.get("warning_type"), w.get("confidence"), w.get("message"),
                       w.get("fingerprint"),
                       [{"file": w.get("file"), "line": w.get("line"),
                         "note": f"user_input: {w.get('user_input')}"}] if w.get("user_input") else []))
    return out


def parse_eslint(d):
    out = []
    for f in d:
        for m in f.get("messages", []):
            if m.get("ruleId"):
                out.append(rec("eslint", m["ruleId"], f.get("filePath"), m.get("line"),
                               ESLINT_CWE.get(m["ruleId"]), severity={1: "warning", 2: "error"}.get(m.get("severity")),
                               message=m.get("message")))
    return out


def parse_semgrep(d):
    out = []
    for r in d.get("results", []):
        ex = r.get("extra", {})
        md = ex.get("metadata", {})
        trace = []
        dt = ex.get("dataflow_trace") or {}
        def push(node, note):
            # semgrep encodes locations as ["CliLoc", [{path,start..}, content]] or nested lists
            s = json.dumps(node)
            for m in re.finditer(r'"path":\s*"([^"]+)".*?"start":\s*\{[^}]*"line":\s*(\d+)', s):
                trace.append({"file": m.group(1), "line": int(m.group(2)), "note": note})
        if dt.get("taint_source"):
            push(dt["taint_source"], "source")
        for iv in dt.get("intermediate_vars", []) or []:
            trace.append({"file": iv.get("location", {}).get("path"),
                          "line": iv.get("location", {}).get("start", {}).get("line"),
                          "note": f"via {iv.get('content')}"})
        if dt.get("taint_sink"):
            push(dt["taint_sink"], "sink")
        out.append(rec("semgrep", r.get("check_id"), r.get("path"),
                       r.get("start", {}).get("line"), first_cwe(md.get("cwe")),
                       ex.get("severity"), md.get("confidence"), ex.get("message"),
                       ex.get("fingerprint"), trace))
    return out


def parse_njsscan(d):
    out = []
    for section in ("nodejs", "templates"):
        for rid, v in (d.get(section) or {}).items():
            md = v.get("metadata", {})
            for f in v.get("files", []):
                ml = f.get("match_lines") or [None]
                out.append(rec("njsscan", rid, f.get("file_path"), ml[0],
                               md.get("cwe"), md.get("severity"), None,
                               md.get("description")))
    return out


def parse_trufflehog(lines):
    out = []
    for ln in lines:
        ln = ln.strip()
        if not ln.startswith("{"):
            continue
        try:
            o = json.loads(ln)
        except json.JSONDecodeError:
            continue
        data = o.get("SourceMetadata", {}).get("Data", {})
        src = next(iter(data.values()), {}) if data else {}
        out.append(rec("trufflehog", o.get("DetectorName"), src.get("file"), src.get("line"),
                       "798", "secret", "verified" if o.get("Verified") else "unverified",
                       f"{o.get('DetectorName')} secret ({'VERIFIED LIVE' if o.get('Verified') else 'unverified'})",
                       extra={"commit": src.get("commit"), "verified": bool(o.get("Verified")),
                              "redacted": o.get("Redacted") or None}))
    return out


def parse_spotbugs(root):
    out = []
    # SpotBugs XML puts cweid on <BugPattern type=..> entries, not on each BugInstance.
    pattern_cwe = {p.get("type"): p.get("cweid") for p in root.iter("BugPattern") if p.get("cweid")}
    for b in root.iter("BugInstance"):
        sl = b.find("SourceLine")
        f = sl.get("sourcepath") if sl is not None else None
        ln = sl.get("start") if sl is not None else None
        msg = b.findtext("LongMessage") or b.findtext("ShortMessage")
        out.append(rec("spotbugs", b.get("type"), f, ln, b.get("cweid") or pattern_cwe.get(b.get("type")) or SPOTBUGS_CWE.get(b.get("type")),
                       b.get("priority"), b.get("rank"), msg))
    return out


def load(path):
    text = open(path, encoding="utf-8", errors="replace").read()
    s = text.lstrip()
    if s.startswith("<"):
        return parse_spotbugs(ET.fromstring(text))
    try:
        d = json.loads(text)
    except json.JSONDecodeError:
        return parse_trufflehog(text.splitlines())  # NDJSON
    if isinstance(d, list):
        return parse_eslint(d)
    if "runs" in d:
        return parse_sarif(d)
    if "Issues" in d:
        return parse_gosec(d)
    if "warnings" in d and "scan_info" in d:
        return parse_brakeman(d)
    if "results" in d and "metrics" in d:
        return parse_bandit(d)
    if "results" in d and isinstance(d["results"], list) and d["results"] and "check_id" in d["results"][0]:
        return parse_semgrep(d)
    if "results" in d and "paths" in d:
        return parse_semgrep(d)
    if "nodejs" in d or "templates" in d:
        return parse_njsscan(d)
    if "DetectorName" in d:
        return parse_trufflehog([text])
    sys.stderr.write(f"[normalize] unrecognized format: {path}\n")
    return []


def main(paths):
    findings = []
    for p in paths:
        for f in load(p):
            f["source_file"] = p
            findings.append(f)
    groups = defaultdict(list)
    for i, f in enumerate(findings):
        key = f"{f['cwe'] or f['rule']}|{f['file']}|{f['line']}"
        f["id"] = f"F{i + 1:03d}"
        f["group_key"] = key
        groups[key].append(f["id"])
    by_cwe_file = defaultdict(list)
    for f in findings:
        if f["cwe"] and f["line"]:
            by_cwe_file[(f["cwe"], f["file"])].append(f)
    for f in findings:
        f["duplicates"] = [x for x in groups[f["group_key"]] if x != f["id"]]
        # Same CWE + file within RELATED_LINES, from a different tool: likely the
        # same root cause reported at build site vs sink. Confirm manually.
        tool = f["tool"].lower().split()[0]
        f["related"] = [g["id"] for g in by_cwe_file.get((f["cwe"], f["file"]), [])
                        if g is not f and g["id"] not in f["duplicates"]
                        and g["tool"].lower().split()[0] != tool
                        and abs(g["line"] - f["line"]) <= RELATED_LINES]
    json.dump({"count": len(findings), "groups": len(groups), "findings": findings},
              sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    args = sys.argv[1:]
    if "--root" in args:
        i = args.index("--root")
        ROOT = os.path.abspath(args[i + 1])
        del args[i:i + 2]
    if not args:
        sys.exit(__doc__)
    main(args)
