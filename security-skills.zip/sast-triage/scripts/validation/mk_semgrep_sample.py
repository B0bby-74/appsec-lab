import glob, json, os, random, re, sys
R = 'corpora/semgrep-rules'
spec = {'js': (['javascript/**/security/**/*.js', 'typescript/**/*.ts', 'javascript/express/**/*.js'], 16),
        'go': (['go/**/security/**/*.go', 'go/lang/security/**/*.go'], 8),
        'ruby': (['ruby/**/security/**/*.rb', 'ruby/rails/**/*.rb'], 8)}
LEAK = re.compile(r'\w*(bad|good|ok|safe|vuln|insecure|secure|unsafe|exploit|danger|benign|evil|attack|fix|correct)\w*', re.I)
ANN = re.compile(r'(todo)?(ruleid|ok|deepok|deepruleid|todoruleid|todook)\s*:', re.I)
COMMENT = re.compile(r'^\s*(//|#|/\*|\*)')
random.seed(42)
out = []
for lang, (globs, n) in spec.items():
    files = sorted({f for g in globs for f in glob.glob(f'{R}/{g}', recursive=True)})
    cands = []
    for f in files:
        lines = open(f, errors='replace').read().splitlines()
        rule_yaml = os.path.splitext(f)[0] + '.yaml'
        if not os.path.exists(rule_yaml): continue
        for i, l in enumerate(lines):
            m = re.search(r'(?:^|\s)(ruleid|ok)\s*:\s*([\w.-]+)', l)
            if m and COMMENT.match(l):
                j = i + 1
                while j < len(lines) and (not lines[j].strip() or COMMENT.match(lines[j])): j += 1
                if j < len(lines): cands.append((f, j, m.group(1) == 'ruleid', m.group(2)))
    pos = [c for c in cands if c[2]]; neg = [c for c in cands if not c[2]]
    pick = random.sample(pos, n // 2) + random.sample(neg, n - n // 2)
    for f, j, real, rule in pick:
        lines = open(f, errors='replace').read().splitlines()
        lo, hi = max(0, j - 14), min(len(lines), j + 6)
        ctx = []
        for k in range(lo, hi):
            l = lines[k]
            if COMMENT.match(l) or ANN.search(l): continue
            l = LEAK.sub('ID', l)
            ctx.append(('>> ' if k == j else '   ') + l)
        out.append({'id': f'{lang}-{len(out)+1:02d}', 'lang': lang, 'file': f, 'line': j + 1, 'rule': rule, 'real': real, 'ctx': ctx})
random.shuffle(out)
json.dump(out, open('val/sg-sample-LABELS-hidden.json', 'w'))
with open('val/sg-sample-blind.txt', 'w') as w:
    for o in sorted(out, key=lambda x: x['id']):
        w.write(f"######## {o['id']}  rule={LEAK.sub('ID', o['rule'].split('.')[-1])}\n" + "\n".join(o['ctx']) + "\n")
print(len(out))
