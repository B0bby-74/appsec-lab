"""Score normalized findings against an OWASP Benchmark expectedresults CSV.
A test case counts as 'flagged' by a tool if any finding in BenchmarkTestNNNNN.* has the case's CWE
(or an equivalent CWE in ALIASES). Usage: score.py expected.csv findings.json [tool]"""
import csv, json, re, sys
from collections import defaultdict
ALIASES = {"22": {"22", "23", "36", "73"}, "78": {"78", "77"}, "79": {"79", "80"}, "89": {"89", "564"},
           "327": {"327", "326", "310"}, "328": {"328", "327", "916"}, "330": {"330", "338"},
           "501": {"501"}, "614": {"614", "1004"}, "643": {"643"}, "90": {"90"}, "502": {"502"},
           "611": {"611"}, "94": {"94", "95"}, "601": {"601"}, "1333": {"1333"}}
exp = {}
for row in csv.reader(open(sys.argv[1])):
    if row[0].startswith("#"): continue
    exp[row[0].strip()] = (row[1].strip(), row[2].strip() == "true", row[3].strip())
fs = json.load(open(sys.argv[2]))["findings"]
tool = sys.argv[3] if len(sys.argv) > 3 else None
hits = defaultdict(set)
for f in fs:
    if tool and not f["tool"].lower().startswith(tool): continue
    m = re.search(r"(BenchmarkTest\d+)", f["file"] or "")
    if m and f["cwe"]: hits[m.group(1)].add(f["cwe"].split("-")[1])
by = defaultdict(lambda: [0, 0, 0, 0])  # TP FN FP TN
flagged = []
for t, (cat, real, cwe) in exp.items():
    hit = bool(hits[t] & ALIASES.get(cwe, {cwe}))
    k = by[f"{cat} (CWE-{cwe})"]
    k[(0 if hit else 1) if real else (2 if hit else 3)] += 1
    if hit: flagged.append((t, cat, cwe, real))
print(f"{'category':28} {'TP':>4} {'FN':>4} {'FP':>4} {'TN':>4}  {'TPR':>5} {'FPR':>5}  precision")
T = [0, 0, 0, 0]
for c, v in sorted(by.items()):
    T = [a + b for a, b in zip(T, v)]
    tp, fn, fp, tn = v
    print(f"{c:28} {tp:4} {fn:4} {fp:4} {tn:4}  {tp/max(tp+fn,1):5.2f} {fp/max(fp+tn,1):5.2f}  {tp/max(tp+fp,1):5.2f}")
tp, fn, fp, tn = T
print(f"{'TOTAL':28} {tp:4} {fn:4} {fp:4} {tn:4}  {tp/max(tp+fn,1):5.2f} {fp/max(fp+tn,1):5.2f}  {tp/max(tp+fp,1):5.2f}")
json.dump(flagged, open(sys.argv[2] + f".flagged-{tool or 'all'}.json", "w"))
