import json, sys
labels = {t: (cat, real) for t, cat, cwe, real in json.load(open(sys.argv[1]))}
v = dict(l.split() for l in open(sys.argv[2]) if l.strip())
ok = falseFP = missedFP = 0
for t, verdict in v.items():
    cat, real = labels[t]
    said_real = verdict == "TP"
    good = said_real == real
    ok += good
    if real and not said_real: falseFP += 1
    if not real and said_real: missedFP += 1
    if not good: print("WRONG", t, cat, "verdict", verdict, "label", "real" if real else "not-real")
n = len(v); reals = sum(1 for t in v if labels[t][1])
print(f"n={n} (real={reals}, not-real={n-reals}) accuracy={ok}/{n}={ok/n:.0%}  dangerous(real called FP/NE)={falseFP}  wasted(safe called TP)={missedFP}")
