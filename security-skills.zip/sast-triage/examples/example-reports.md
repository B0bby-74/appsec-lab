# Example reports

Produced by following this skill on a small Flask app (`app.py`) where Bandit reported B608 twice. Both verification steps below were actually run: the re-scan and the regression test results are real.

```python
 5  @app.route("/user")
 6  def user():
 7      uid = request.args.get("id")
 8      q = "SELECT * FROM users WHERE id = '%s'" % uid
 9      cur = sqlite3.connect("x.db").cursor()
10      cur.execute(q)
11      return "ok"
12
13  @app.route("/safe")
14  def safe():
15      uid = int(request.args.get("id"))
16      cur = sqlite3.connect("x.db").cursor()
17      cur.execute("SELECT * FROM users WHERE id = %d" % uid)
18      return "ok"
```

## 1. User selects line 8 and runs `/sast-triage bandit B608 SQL injection`

```
═══ FINDING REPORT ═══════════════════════════════════════════
Finding   : app.py-L8   Scanner: Bandit   Rule: B608   CWE-89 SQL Injection
Location  : app.py:8
Verdict   : TRUE POSITIVE
Severity  : scanner MEDIUM → adjusted HIGH  (why: unauthenticated GET route, attacker reads any row)

ROOT CAUSE
  SQL built by %-formatting request.args["id"] into the query string instead of a bound parameter.

SOURCE → SINK
  SOURCE     app.py:7   uid = request.args.get("id")                       ← query string, attacker-controlled
  STEP       app.py:8   q = "SELECT ... id = '%s'" % uid                   ← value inserted into SQL text
  SANITIZER  none
  SINK       app.py:10  cur.execute(q)
  Entry point: GET /user    Attacker controls: the whole id value, e.g. ' OR '1'='1

REMEDIATION
  Pass id as a bound parameter so the database treats it as data, never as SQL.
  Escaping quotes or blocklisting characters is not sufficient. No functional cost.

FIX DETAILS
  SEC-FIX01  app.py:8-10
    Before : q = "SELECT * FROM users WHERE id = '%s'" % uid
             cur.execute(q)
    After  : cur.execute("SELECT * FROM users WHERE id = ?", (uid,))
    Comment: # SEC-FIX01 app.py-L8 CWE-89: bind id as a parameter instead of string formatting

VERIFY
  Re-scan : bandit -t B608 app.py   → line 8 no longer reported   [RUN: confirmed]
  Test    : test_sqli.py — GET /user?id=' OR '1'='1
            old code: returns 2 rows (fails)   new code: returns 0 rows (passes)   [RUN: confirmed]
  Similar code: app.py:17 also uses %-formatting in SQL (see report 2, false positive)
═══════════════════════════════════════════════════════════════
```
> **Apply this fix?** Reply **yes** to apply SEC-FIX changes, **suppress** to add the suppression instead, or **no** to leave the code unchanged.

## 2. User selects line 17 and runs `/sast-triage bandit B608 SQL injection`

```
═══ FINDING REPORT ═══════════════════════════════════════════
Finding   : app.py-L17   Scanner: Bandit   Rule: B608   CWE-89 SQL Injection
Location  : app.py:17
Verdict   : FALSE POSITIVE
Severity  : scanner MEDIUM → adjusted NONE

ROOT CAUSE
  Bandit flags any string formatting inside SQL text; it does not check the value's type.

SOURCE → SINK
  SOURCE     app.py:15  uid = int(request.args.get("id"))   ← attacker input, converted to int
  SANITIZER  app.py:15  int(...)   ← fits the sink: an int formatted with %d can only be digits;
                                     non-numeric input raises ValueError before the query runs
  SINK       app.py:17  cur.execute("... id = %d" % uid)
  Entry point: GET /safe    Attacker controls: only which integer is used

JUSTIFICATION
  The value reaching SQL is always an integer (app.py:15), so no SQL syntax can be injected.
  Recommended anyway (not required): use a bound parameter for consistency, which also removes the finding.
  Side note: non-numeric input causes an unhandled ValueError (HTTP 500), a robustness bug, not injection.

SUPPRESSION
  app.py:17   cur.execute("SELECT * FROM users WHERE id = %d" % uid)  # nosec B608 -- app.py-L17 id is int() at line 15
  Also mark as false positive in Kondukto (if used), with the same justification.
═══════════════════════════════════════════════════════════════
```
> **Apply this fix?** Reply **yes** to apply SEC-FIX changes, **suppress** to add the suppression instead, or **no** to leave the code unchanged.
