# Validation results — 2026-11-20

Triage verdicts were made **blind** (labels hidden in a separate file until all verdicts in a set were recorded), then scored by script against labels written by third parties (OWASP Benchmark, Semgrep rule authors, OWASP Juice Shop). The triager was the same model that wrote the skill — an independent reviewer re-running `scripts/validation/` is the stronger check.

## 1. Raw scanner accuracy (no triage) — why triage is needed

| Corpus | Tool(s) | Real vulns caught (TPR) | Safe cases flagged (FPR) | Precision |
|---|---|---|---|---|
| OWASP Benchmark Python 0.1 (1,230 cases) | Bandit 1.x | 40% | 3% | 0.88 |
| | Semgrep CE 1.186 + community rules | 32% | 14% | 0.58 |
| | combined | 53% | 15% | 0.67 |
| OWASP Benchmark Java 1.2 (2,740 cases) | SpotBugs 4.8.6 + FindSecBugs 1.13.0 | 97% | 55% | 0.65 |
| | Semgrep CE 1.186 + community rules | 88% | 42% | 0.69 |
| OWASP Juice Shop (TypeScript, 31 marked vuln lines) | Semgrep CE (JS+TS rules) | 7 / 31 lines | n/a | n/a |
| | njsscan 1.0.2 | **0 / 31 — scans .js only, silent on .ts** | | |

FindSecBugs flagged *every* case in six injection categories (100% FPR there). Bandit and Semgrep both missed whole Python categories (XPath, LDAP, XSS, trust boundary) — a clean scan is not proof of absence.

## 2. Triage verdict accuracy (the skill)

| Set | Language | n (real / not real) | Agreed with label | Real vuln dismissed | Safe called real |
|---|---|---|---|---|---|
| Benchmark Python, stratified random from flagged | Python | 32 (14 / 18) | **32/32** | 0 | 0 |
| Benchmark Java, stratified random from flagged | Java | 21 (15 / 6) | **21/21** | 0 | 0 |
| Semgrep rule tests (`ruleid` vs `ok` lines) | JS/TS | 16 (8 / 8) | 14/16 | 2 | 0 |
| | Go | 8 (4 / 4) | 6/8 | 2 | 0 |
| | Ruby | 8 (4 / 4) | 6/8 | 0 | 2 |
| **Total** | | **85** | **79/85 (93%)** | 4 | 2 |

Disagreement review (full source inspected afterwards):
- **Genuine skill errors (3):** sax XXE — called FP from a truncated window; a `doctype` handler was registered further down (should have been Needs Review). Rails `logger.debug(params)` — called TP; debug logs are off in production by default. Go Host-header redirect — dismissed Host as non-attacker input; should be Not Exploitable *with stated dependency* or Low TP.
- **Label-definition differences (3):** Semgrep `ruleid` means "rule should match", not "exploitable": a constant interpolated into an HTML template (js), a write behind an always-true `isValid` stub (go), and unsalted SHA-256 password hashing which the MD5-specific rule labels `ok` but is still CWE-916 (ruby).
- Each genuine error became a rule in SKILL.md ("Lessons from validation runs").

Benchmark caveat: OWASP Benchmark cases use a small set of repeated patterns (dead branches, constant overwrites, helper pass-throughs). 100% there is an upper bound, not an expectation for production code.

## 3. Fix selection (mitigation quality)

OWASP Juice Shop ships 3–4 candidate fixes per challenge with the correct one labelled. Candidates were shuffled and renamed A–D.

| Challenge | Result |
|---|---|
| loginJim (SQLi) | correct — bound params *and* kept password hashing |
| redirect (open redirect) | correct — exact match over `includes()` |
| xssBonus (Angular XSS) | correct — remove `bypassSecurityTrust*` |
| accessLogDisclosure | correct — remove both listing and file route |
| chatbotGreedyInjection (LLM) | correct — enforce `max(10)` in schema, not in prompt |
| directoryListing | **wrong** — chose "remove listing, keep downloads" despite noting guessable files stay downloadable; correct was remove `/ftp` and relocate content |

**5/6.** The miss became the "No known residual path" rule in SKILL.md.

## 4. Tooling defects found and fixed by running real output
- `normalize.py`: O(n²) grouping took minutes on 18k findings → indexed, now ~1 s.
- SpotBugs XML had no CWE → bug-type → CWE map.
- ESLint JSON has no CWE and absolute paths → rule → CWE map + path relativization; ESLint now groups with njsscan/Semgrep on the same lines.
- Semgrep CE 1.186 emits dataflow traces only in text output (documented in `scanners/semgrep.md`).
- ESLint 9 flat config silently ignores files outside the config dir (documented).

## Not covered yet
- Snyk Code, Invicti, Kondukto, TruffleHog, Brakeman, gosec: parsers/guidance checked against documentation and hand-made samples only — no real output was available here (Snyk/Invicti/Kondukto need accounts; Brakeman/gosec/TruffleHog runs are a next step).
- Suppression syntax was not exercised end-to-end (add suppression → re-scan → finding gone) for each tool.

## Re-run
```bash
python3 scripts/normalize.py <scanner outputs> > norm.json
python3 scripts/validation/score.py <expectedresults.csv> norm.json [tool]   # scanner TPR/FPR on OWASP Benchmark
python3 scripts/validation/mk_semgrep_sample.py                               # blind labelled sample from semgrep-rules tests
python3 scripts/validation/score_triage.py <labels.json> <verdicts.txt>       # score your verdicts
```
