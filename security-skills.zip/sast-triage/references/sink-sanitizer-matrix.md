# Sink → correct control → look-alike controls

Use this to decide whether a "sanitizer" on the path actually fits the sink. A control only counts if it applies on **every** path to the sink and runs **after** the last attacker-influenced transformation.

| CWE | Typical sinks | Correct control | Looks right but isn't |
|---|---|---|---|
| 89 SQL injection | `cursor.execute(f"..")`, `db.Query("..."+x)`, `Statement.executeQuery`, `sequelize.query`, `where("id = #{x}")` (Rails), `.raw()`/`.extra()` (Django) | Bound parameters / ORM query builder; allow-list for identifiers (table/column/ORDER BY) | HTML escaping; `replace("'", "''")` alone; type-hinting without conversion; parameterizing values but concatenating identifiers |
| 78 OS command | `subprocess(..., shell=True)`, `os.system`, `exec.Command("sh","-c",x)`, `child_process.exec`, backticks/`system` in Ruby, `Runtime.exec(String)` | Arg-vector API without shell + allow-list of the program; `--` before user args | `shlex.quote` then passing to a different shell; blocklist of `;&|`; escaping on Windows `cmd` |
| 79 XSS | `innerHTML`, `dangerouslySetInnerHTML`, `v-html`, `|safe`, `mark_safe`, `raw`/`html_safe` (Rails), `template.HTML(x)` (Go), `res.send(x)` with text/html | Context-aware auto-escaping template; DOMPurify for intended HTML; `textContent` | URL-encoding in HTML context; escaping in JS-string context with HTML encoder; sanitizing on input then re-concatenating |
| 22 Path traversal | `open(base + x)`, `os.path.join(base, x)`, `filepath.Join`, `fs.readFile`, `send_file`, `new File(base, x)` | Canonicalize (`realpath`/`filepath.Clean`+`Abs`/`path.resolve`) **then** check prefix of base dir; or map IDs to files | `normalize` without prefix check; stripping `../` once (`....//`); prefix check before canonicalization; `os.path.join` with absolute `x` discards base |
| 918 SSRF | `requests.get(x)`, `http.Get(x)`, `axios(x)`, `URL.openConnection`, `Net::HTTP` | Allow-list of hosts after parsing; resolve DNS and block private/link-local ranges; disable redirects or re-validate | Regex on URL string; blocking `localhost` text only; checking host before redirect follow |
| 502 Deserialization | `pickle.loads`, `yaml.load` (unsafe Loader), `ObjectInputStream.readObject`, `Marshal.load`, `node-serialize`, `encoding/gob` on untrusted | Data-only formats (JSON) + schema; `yaml.safe_load`; class allow-list (look-ahead `ObjectInputFilter`) | Signing without verification; "only internal clients send this" without auth |
| 611 XXE | `DocumentBuilderFactory`, `SAXParser`, `XMLInputFactory`, `lxml` with `resolve_entities=True` | Disable DTDs / external entities on the factory; `defusedxml` | Setting one feature on one parser but another factory used elsewhere |
| 601 Open redirect | `redirect(x)`, `res.redirect(x)`, `http.Redirect`, `redirect_to params[:x]` | Allow-list of paths/hosts; relative-path only with `//` and `\` rejected | `startswith("/")` (allows `//evil.com`); substring host check |
| 94/95 Code injection | `eval`, `exec`, `Function()`, `vm.runInContext`, `instance_eval`, `send(params[:m])`, SpEL/OGNL eval | Remove dynamic eval; dispatch table / allow-list | Sandboxing via `vm` module (not a security boundary) |
| 1333 ReDoS | User-supplied regex, or catastrophic pattern on user input | Linear engine (RE2), length limits, rewrite pattern | Timeouts on single-threaded Node without worker |
| 327/328 Weak crypto | `md5`, `sha1`, `DES`, `ECB`, `random`/`Math.random` for tokens | SHA-256+ / AES-GCM / `secrets`/`crypto.randomBytes`; bcrypt/argon2 for passwords | Using MD5 for non-security checksum is usually **FP** — confirm the use |
| 798 Hardcoded secret | literals in code/config | Secret manager / env injection + rotation | Base64-encoding the secret; moving it to another committed file |
| 295 TLS validation | `verify=False`, `InsecureSkipVerify: true`, `rejectUnauthorized: false`, custom TrustManager | Remove; pin CA bundle if needed | "only used in dev" without build-time guard |
| 639/862 Authz (IDOR) | Lookups by user-supplied ID | Scope query by current principal; policy check | Obscure/UUID IDs alone |

## Frequent false-positive patterns (verify, don't assume)
- Value traced to a constant, enum, or config read at startup by operators (not users).
- Sink is a test file, fixture, migration, or build script not shipped — confirm it isn't packaged.
- Rule matched by name only (e.g. any method called `exec` / `query`) on a non-dangerous API.
- Typed conversion (`int(x)`, `strconv.Atoi`, `Integer.parseInt`) before the sink with error handling — makes injection impossible for that value.
- Framework auto-escaping is on and output isn't marked safe.
- `MD5`/`SHA1` used for cache keys, ETags, non-security dedupe.
- Bracket access with a key from a fixed set (eslint `detect-object-injection`).
