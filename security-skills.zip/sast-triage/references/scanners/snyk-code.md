# Snyk Code (SAST)

**Run:**
```bash
snyk code test --sarif-file-output=snyk.sarif     # or --json-file-output=snyk.json
```
Record CLI version and org.

**Fields (SARIF):** `ruleId` (e.g. `javascript/Sqli`), `message.text`, `locations`, `fingerprints`, rule `properties.cwe`, `properties.priorityScore`.
**Trace:** `codeFlows[0].threadFlows[0].locations[]` — ordered source→sink steps. Snyk traces are interprocedural but can jump over framework code; verify each hop, and check whether a sanitizer on the path is one Snyk doesn't model.

**Suppress / ignore:** Snyk Code ignores are managed in the Snyk platform (web UI / API ignore with reason + expiry), not by inline comments; the `.snyk` policy file is primarily for Snyk Open Source. Confirm what your org's Snyk setup supports. Always set a reason and expiry; reference the justification record.

**Common FPs:** custom validation helpers not recognized as sanitizers; data from trusted internal config flagged as source; test files.

**Verify:** re-run `snyk code test` on the fix branch; the fingerprint must be absent.
