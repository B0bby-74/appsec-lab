# gosec (Go)

**Run:**
```bash
gosec -fmt=sarif -out=gosec.sarif ./...
gosec -fmt=json  -out=gosec.json  -track-suppressions ./...
```
**Fields (JSON):** `Issues[]`: `rule_id` (G101…), `cwe.id`, `severity`, `confidence`, `file`, `line` (string, may be a range "12-14"), `code`, `details`; `-track-suppressions` adds existing suppressions.
**Trace:** none for most rules — pattern/AST checks at the sink. Build the trace manually; `go doc`/`gopls` find-references or `callgraph` (golang.org/x/tools) help walk callers.

**Suppress (one rule, with justification):**
```go
rows, err := db.Query(q) // #nosec G201 -- SEC-123 q built from constant column allow-list
```
Do not use bare `#nosec`. Exclude rules globally only via `-exclude=` in config with a written reason.

**Common FPs:** G101 hardcoded creds on variable names like `passwordField`; G304 file path from a constant/config; G404 `math/rand` for non-security jitter; G115 integer conversion already bounds-checked.

**Rule IDs worth knowing:** G101 creds, G104 unchecked errors, G107 URL from variable (SSRF), G201/G202 SQL string build, G204 subprocess with variable, G304 file inclusion, G401-G405 weak crypto, G402 TLS InsecureSkipVerify.
