# Brakeman (Rails)

**Run:**
```bash
brakeman -f json -o brakeman.json      # also -f sarif
```
**Fields:** `warnings[]`: `warning_type`, `warning_code`, `check_name`, `fingerprint` (stable ID), `file`, `line`, `code`, `user_input` (the tainted expression Brakeman saw), `confidence` (High/Medium/Weak), `cwe_id`, `location` (class/method).
**Trace:** partial — `user_input` names the source expression (e.g. `params[:id]`); walk from controller action to the sink yourself. Weak confidence ⇒ Brakeman isn't sure the input is user-controlled; verify.

**Suppress:** `brakeman -I` (interactive) writes `config/brakeman.ignore` with the fingerprint and a `note` — always fill `note` with the justification and ticket. There is no inline-comment suppression; fingerprint changes when the code changes, which forces re-review (good).

**Common FPs:** SQL with `sanitize_sql_*` or integers from `.to_i`; `redirect_to` with `only_path: true`; `html_safe` on constant strings; mass assignment where strong params are in a helper Brakeman didn't follow.
