# njsscan (Node.js; built on libsast + semgrep patterns)

**Run:**
```bash
njsscan --sarif -o njsscan.sarif .
njsscan --json  -o njsscan.json  .
```
**Coverage gap (tested, njsscan 1.0.2):** njsscan scans `.js` only. On a TypeScript codebase (OWASP Juice Shop, all `.ts`) it returned **zero findings with no error or warning**. An empty njsscan report on a TS project is not evidence of safety — use Semgrep JS/TS rules or Snyk Code there, and say so in the report.

**Fields (JSON):** `nodejs` / `templates` sections keyed by rule ID, each with `files[]` (`file_path`, `match_lines`, `match_string`) and `metadata` (`cwe`, `owasp-web`, `severity`, `description`).
**Trace:** none in output (pattern-based). Build manually.

**Suppress:** inline `// njsscan-ignore: <rule_id>` on the line, or `.njsscan` config (`ignore-rules`, `ignore-paths`) for out-of-scope paths. Add the reason and ticket after the ignore.

**Common FPs:** `express_xss` on `res.send` of JSON/objects; `node_sqli_injection` with parameterized queries using template literals for constant parts; `generic_path_traversal` with `path.join` of constants.
