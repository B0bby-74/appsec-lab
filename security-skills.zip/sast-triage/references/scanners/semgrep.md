# Semgrep CE

**Run (raw output with traces):**
```bash
semgrep scan --config <rules> --sarif --dataflow-traces -o semgrep.sarif
semgrep scan --config <rules> --json --dataflow-traces -o semgrep.json
```
Record `semgrep --version` and the rule source (registry ruleset name or local YAML path + commit).

**Fields:** `check_id` (rule), `path`, `start.line`, `extra.message`, `extra.metadata.cwe`, `extra.metadata.confidence`, `extra.fingerprint`.
**Trace:** only for `mode: taint` rules. **Tested on Semgrep CE 1.186.0: `--dataflow-traces` populates only the text output** ("Taint comes from / intermediate variables / how taint reaches the sink"); JSON `extra.dataflow_trace` and SARIF `codeFlows` were absent. So run a second pass for the trace:
```bash
semgrep scan --config <rules> --dataflow-traces --text <path>
```
(Other versions / Semgrep Pro may emit `extra.dataflow_trace` in JSON and `codeFlows` in SARIF — `normalize.py` reads them if present.) Pattern (non-taint) rules give the sink only — you build the trace.

Semgrep taint rules report at the **sink** line; Bandit/gosec often report where the string is **built** (a few lines earlier). `normalize.py` lists these as `related` across tools — confirm and treat as one root cause.

**Read the rule** (`semgrep --config <rule> --dump-ast` is not needed; just open the YAML): check `pattern-sanitizers`, `pattern-not`, `focus-metavariable`. Many FPs come from a missing sanitizer in the rule that your code does use.

**Suppress (one rule, one line):**
```python
cursor.execute(q, params)  # nosemgrep: python.lang.security.audit.formatted-sql-query -- SEC-123 bound params
```
Use `//` in JS/Go/Java. Path exclusions go in `.semgrepignore` (tests/vendored only).

**Verify fix:** `semgrep scan --config <same rules> --baseline-commit <pre-fix-sha>` reports only findings new relative to baseline; also re-run full and confirm the finding ID is gone.

**Variant analysis:** write a taint rule from the confirmed trace:
```yaml
rules:
- id: variant-<finding>
  mode: taint
  languages: [python]
  severity: ERROR
  message: user input reaches raw SQL
  pattern-sources: [{pattern: request.args.get(...)}]
  pattern-sinks:   [{pattern: $CUR.execute($Q, ...)}]
  pattern-sanitizers: [{pattern: int(...)}]
```
