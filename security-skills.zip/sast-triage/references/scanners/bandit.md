# Bandit (Python)

**Run:**
```bash
bandit -r . -f json -o bandit.json      # SARIF: -f sarif (bandit[sarif] extra)
```
**Fields:** `results[]`: `test_id` (B608…), `test_name`, `filename`, `line_number`, `line_range`, `issue_severity`, `issue_confidence`, `issue_cwe.id`, `code`.
**Trace:** none — AST checks at the sink. Build the trace manually.

**Suppress (one test ID):**
```python
cur.execute(sql)  # nosec B608 -- SEC-123 sql composed only from ALLOWED_COLUMNS
```
Bare `# nosec` suppresses everything on the line — avoid. Baselines: `bandit -b baseline.json` to report only new issues. Skip tests dirs via `-x tests` / `.bandit` config, stated as out-of-scope.

**Common FPs:** B101 `assert` in tests; B105/B106 hardcoded password on strings like `"password"` used as field names; B311 `random` for non-security; B608 f-string SQL where all interpolated parts are constants; B603 subprocess without shell and fixed argv; B324 md5 with `usedforsecurity=False`.
