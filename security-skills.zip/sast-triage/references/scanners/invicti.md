# Invicti (DAST, optionally IAST) — map back to code

Invicti attacks the running app. Findings have a URL, parameter, payload and the HTTP request/response proof — **no source file**. Many are "Confirmed" via proof-based scanning (it actually exploited it); confirmed findings are rarely FPs.

**Raw material:** export the vulnerability with full HTTP request/response (XML/JSON export or API), the `Certainty`/confirmed flag, CWE, CVSS, affected parameter. If the IAST agent (Shark) was deployed, the finding may include a stack trace / file:line — use it.

**Map to code:**
1. URL + method → route definition (framework router, `routes.rb`, `@app.route`, `@GetMapping`, express router).
2. Handler → follow the vulnerable parameter forward to the sink. This gives the same SOURCE→SINK trace as SAST.
3. If a SAST tool also flagged that sink, link them as duplicates.

**Reproduce:** replay the request (curl/Burp) against a local or staging build; the replay becomes the regression test payload.

**FP / risk acceptance:** mark state in Invicti (false positive / accepted risk) so re-scans don't reopen, and in Kondukto if aggregated. Common FPs: reflected input in a non-HTML content type, version-disclosure findings behind a proxy that rewrites headers, findings on third-party hosted paths.

**Verify:** Invicti "retest" of that vulnerability after deploy must report fixed.
