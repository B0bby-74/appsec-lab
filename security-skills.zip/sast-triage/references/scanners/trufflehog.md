# TruffleHog v3 (secrets) — different workflow

A leaked secret is not fixed by editing code. It remains in git history, forks, CI logs, caches and built images, and it works until revoked.

**Run:**
```bash
trufflehog git file://. --json > trufflehog.ndjson            # full history
trufflehog git file://. --json --results=verified,unknown      # newer versions; older: --only-verified
trufflehog filesystem . --json
```
**Fields (NDJSON, one object per line):** `DetectorName`, `Verified` (live at scan time), `Raw`/`Redacted` (never print `Raw` in reports), `SourceMetadata.Data.Git.{commit,file,line,email,timestamp,repository}` or `.Filesystem.{file,line}`.

**Workflow:**
1. **Verified?** If `Verified: true` → treat as incident: revoke/rotate immediately, before any cleanup. If unverified → determine whether it is expired, a test/dummy value, or a detector the tool can't verify; don't assume dead.
2. **Scope:** first commit containing it (`git log -S '<prefix>' --all --oneline`, use a non-sensitive prefix), repo visibility, forks, CI logs, Docker images, packages.
3. **Revoke & rotate** at the provider; move to a secret manager / CI secret; update consumers.
4. **Review use:** provider access logs for the exposure window.
5. **History:** `git filter-repo --replace-text` or BFG, force-push, ask collaborators to re-clone — only after revocation and with owner approval (destructive).
6. **Prevent:** pre-commit hook (`trufflehog git file://. --since-commit HEAD --fail` or gitleaks).

**False positive:** test fixtures, example keys from docs (e.g. AWS `AKIAIOSFODNN7EXAMPLE`), high-entropy non-secrets. Suppress with `trufflehog:ignore` comment on the line, or `--exclude-paths <file>` for fixture dirs.

**Done:** provider confirms revocation and re-scan shows `Verified: false`; record filled per `templates.md` → Secret record.
