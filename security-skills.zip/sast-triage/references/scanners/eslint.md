# ESLint security rules (eslint-plugin-security, eslint-plugin-no-unsanitized, etc.)

**Run:**
```bash
npx eslint . -f json -o eslint.json
npx eslint . -f @microsoft/eslint-formatter-sarif -o eslint.sarif
```
**ESLint 9 flat config gotcha (tested):** files outside the directory containing `eslint.config.mjs` are silently treated as ignored ("all of the files matching the glob pattern are ignored") and no JSON is written. Run from the repo root with `-c <config>`, and ensure the JSON file is non-empty before triaging. ESLint JSON has absolute paths and no CWE — `normalize.py` maps rule IDs to CWEs and relativizes paths so findings group with other tools.

**Fields (JSON):** array of `{filePath, messages:[{ruleId, line, column, message, severity}]}`. Only treat `security/*`, `no-unsanitized/*` and similar security rule IDs as findings.
**Trace:** none — syntactic rules. These are high-noise; most require you to prove source→sink manually.

**Suppress (one rule, with reason — ESLint ≥7 supports `--` descriptions):**
```js
// eslint-disable-next-line security/detect-object-injection -- SEC-123 key from fixed enum STATUS_KEYS
const label = labels[status];
```
Run with `--report-unused-disable-directives` so stale suppressions surface.

**Common FPs:** `detect-object-injection` (any `obj[var]`) — FP unless the key is attacker-controlled and the object has dangerous prototype properties or is used for assignment; `detect-non-literal-fs-filename` with paths from config; `detect-non-literal-regexp` from constants; `detect-child-process` with `execFile` and fixed argv.
