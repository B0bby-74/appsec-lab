# Kondukto (aggregation / ASPM — not a scanner)

Kondukto imports results from the scanners above and normalizes them. Treat it as the **system of record** for verdicts, not as the source of the technical evidence.

- Pull the underlying scanner's raw output (or the raw finding detail Kondukto stores) — Kondukto summaries may drop the dataflow trace.
- Note the Kondukto finding ID and the original tool's rule ID/fingerprint in every template.
- Kondukto deduplicates within a tool; check cross-tool duplicates yourself via CWE + file + line (`normalize.py` `group_key`).
- Record FP and risk-acceptance decisions in Kondukto's workflow (status, justification, approver, expiry as configured in your instance) so they survive re-scans and show in audits. Confirm with your Kondukto admin which approval flow and expiry fields are enabled.
- A code suppression (nosec, nosemgrep…) without a matching Kondukto state can cause drift: the tool stops reporting it, so no one reviews it at expiry. Keep both in sync and reference the Kondukto ID in the suppression comment.
