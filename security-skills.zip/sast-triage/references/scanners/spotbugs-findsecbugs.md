# SpotBugs + FindSecBugs (Java/Kotlin/Scala bytecode)

(Assumed meaning of "Find" — confirm with the user if it is a different tool.)

**Run:** via Maven/Gradle plugin with `com.h3xstream.findsecbugs:findsecbugs-plugin`, or CLI:
```bash
spotbugs -textui -pluginList findsecbugs-plugin.jar -xml:withMessages -output spotbugs.xml target/classes
spotbugs -textui -pluginList findsecbugs-plugin.jar -sarif=spotbugs.sarif target/classes   # SpotBugs 4.x
```
**Fields (XML):** `BugInstance@type` (e.g. `SQL_INJECTION_JDBC`, `PATH_TRAVERSAL_IN`, `COMMAND_INJECTION`), `@priority`, `@rank`, `@cweid`, `Class`, `Method`, `SourceLine@sourcepath/@start`.
**Trace:** none in output; FindSecBugs taint analysis is intra/inter-procedural on bytecode but only reports the sink. Analyses bytecode — line numbers map via debug info; Lombok/Kotlin-generated code can produce odd locations.

**Suppress:**
```java
@SuppressFBWarnings(value = "SQL_INJECTION_JDBC", justification = "SEC-123 query uses allow-listed column name")
```
(from `com.github.spotbugs:spotbugs-annotations`), or an exclude filter:
```xml
<FindBugsFilter><Match><Bug pattern="SQL_INJECTION_JDBC"/><Class name="com.acme.ReportDao"/><Method name="byColumn"/></Match></FindBugsFilter>
```
Scope to class+method+pattern; never a pattern-only global exclude without written reason.

**Measured on OWASP Benchmark Java 1.2 (SpotBugs 4.8.6 + FindSecBugs 1.13.0):** it flagged **every** case in cmdi, ldapi, pathtraver, sqli, trustbound and xpathi — real and safe alike (FP rate 100% in those categories; 769 of 2,144 flagged cases were safe). Expect roughly half of FindSecBugs injection findings to be FPs; trace each one. Crypto/hash/weakrand/securecookie findings were 100% precise.

**CWE:** XML output (`-xml:withMessages`) carried no CWE in this run; `normalize.py` maps common bug types. Informational types (`SERVLET_PARAMETER`, `SERVLET_HEADER`, `COOKIE_USAGE`, `SERVLET_QUERY_STRING`) mark input *sources*, not vulnerabilities — don't triage them as findings.

**Run note:** the `bin/spotbugs` script may lack execute permission in the release tarball; `java -jar lib/spotbugs.jar -textui …` works. Pass `-auxclasspath` (e.g. from `mvn dependency:build-classpath`) or taint tracking through library calls degrades.

**Common FPs:** `PREDICTABLE_RANDOM` for non-security; `SPRING_ENDPOINT` (informational, not a vuln); `CRLF_INJECTION_LOGS` when logging framework encodes; taint through a validated `UUID.fromString`/`Integer.parseInt`.
