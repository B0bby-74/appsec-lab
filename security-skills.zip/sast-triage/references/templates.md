# Output templates

Fill every field. Write "unknown" with the reason rather than omitting a field.

## Verdict header (all findings)
```
Finding:        <finding-id>  (<scanner> <version>, rule <rule-id>)
Also reported:  <duplicate ids from other scanners, or none>
CWE:            CWE-<n> <name>
Location:       <file>:<line>  @ commit <sha>
Verdict:        TRUE POSITIVE | FALSE POSITIVE | NOT EXPLOITABLE | RISK ACCEPTED | DUPLICATE | NEEDS REVIEW
Severity:       scanner <x>  →  adjusted <y>  (CVSS v4: <vector or "not scored">)
Reason for adjustment: <exposure / auth / data sensitivity>

Root cause: <one sentence describing the design flaw>

Trace:
  SOURCE    <file>:<line>  <code>   — <what enters, who controls it>
  STEP 1    <file>:<line>  <code>
  ...
  SANITIZER <file>:<line>  <code> | none   — <fits the sink? why>
  SINK      <file>:<line>  <code>
Entry point: <HTTP method + route / CLI / job / queue>, auth: <none|user|admin>
```

## True Positive — fix record (goes in commit/PR/ticket)
```
Fix for <finding-id> (CWE-<n>)

SEC-FIX01  <file>:<line>
  Before:  <code>
  After:   <code>
  Why:     <how this removes the root cause>

SEC-FIX02  <file>:<line>
  ...

PoC:              <payload / test name that exploited it>
Regression test:  <test file::name>  — fails on old code: yes/no/not run; passes on new: yes/no/not run
Variants found:   <file:line list, or "none — searched with <pattern/rule>">
Verification:     <exact re-scan command>  →  finding <closed|still present>, new findings: <n>
```
In-code comment at each change point (one line only):
`<comment-syntax> SEC-FIXnn <finding-id> CWE-<n>: <what changed>`

## False Positive / Not Exploitable — justification
```
Verdict: FALSE POSITIVE | NOT EXPLOITABLE
What the rule matched: <quote the rule pattern / detector and the matching code>
Why it is not a vulnerability:
  - <e.g. value is a compile-time constant defined at file:line>
  - <e.g. control at file:line enforces allow-list ^[0-9]+$ before the sink>
Control dependency (Not Exploitable only): <control file:line> — if removed, finding becomes a TP
Suppression applied: <file>:<line>  <exact suppression text>
Also marked in: <Kondukto/Snyk/Invicti state + link, or SARIF suppressions entry>
Reviewer: <name/role or "pending">
```

## Risk acceptance record
```
Record ID:            RA-<yyyy>-<nnn>
Finding(s):           <ids>, CWE-<n>, adjusted severity <y>
Description:          <root cause sentence + exploit scenario in plain words>
Reason not fixing now:<business/technical reason>
Compensating controls:<WAF rule id, network restriction, monitoring alert — each verifiable>
Residual risk:        <what an attacker can still do>
Risk owner:           <name, role>
Approver:             <name, role>  (must differ from owner)
Accepted on:          <date>
Expires:              <date>  (≤90d High/Critical, ≤180d Medium, ≤365d Low)
Review date:          <date>
Ticket:               <link>
Code suppression:     <exact text referencing RA id + expiry, or none>
Status:               REQUESTED | APPROVED | EXPIRED
```

## Secret (TruffleHog) record
```
Finding:     <detector> in <file>:<line> @ <commit> (first committed <date> by <author>)
Verified live at scan: yes/no      Re-checked: <date> yes/no
Exposure:    repo visibility <public/private>, forks/mirrors, CI logs, packages/images containing it
Actions:     revoked <date> by <who> | rotated to <secret manager path> | access logs reviewed <range>: <findings>
History:     removed with <git filter-repo/BFG> on <date> | not removed — reason
Prevention:  pre-commit hook <gitleaks/trufflehog> added: yes/no
Status:      OPEN | CONTAINED | CLOSED
```

## Batch summary
```
| ID | Scanner(s) | CWE | file:line | Verdict | Sev (scanner→adj) | Action |
```
