# Validating this skill against known answers

The only objective check on triage quality is running it on code where the right answer is already known, then scoring verdicts.

## Known-answer corpora
| Corpus | Language / scanners | Ground truth |
|---|---|---|
| OWASP Benchmark (github.com/OWASP-Benchmark/BenchmarkJava) | Java — SpotBugs/FindSecBugs, Semgrep, Snyk | `expectedresults-*.csv`: every test case labelled real/not-real vuln with CWE |
| OWASP Juice Shop | Node — ESLint, njsscan, Semgrep, Snyk | Published challenge list / solutions |
| OWASP NodeGoat | Node | Tutorial lists each vulnerability and location |
| RailsGoat | Rails — Brakeman | Wiki lists vulnerabilities per OWASP Top 10 |
| gosec `testutils/` samples | Go — gosec | Each sample annotated with expected issue count |
| Bandit `examples/` | Python — Bandit | Functional tests list expected counts per file |
| Semgrep rule tests (`# ruleid:` / `# ok:` annotations) | multi | Each line labelled true/false |
| TruffleHog: plant a revoked test key + docs example keys in a scratch repo | secrets | You know which is which |

OWASP Benchmark is the best for FP-vs-TP accuracy: roughly half its cases are deliberately safe look-alikes.

## Procedure
1. Pick a fixed sample (e.g. 40 Benchmark cases: 20 true, 20 false, across CWE 22/78/79/89). Don't look at labels.
2. Run the scanner, normalize, triage each finding with this skill.
3. Score against labels:
   - **Verdict accuracy** = correct / total
   - **False-FP rate** (skill said FP/Not Exploitable but it was real) — the dangerous error; target 0
   - **Missed-FP rate** (skill said TP but it was safe) — costs dev time
4. For TP fixes: re-scan and run the case's test; count fixes that close the finding without new findings.
5. Record results with skill version/date; re-run after editing the skill.

## Pass bar (suggested)
- False-FP rate 0 on the sample; verdict accuracy ≥ 90%; every FP/Not-Exploitable verdict has a file:line trace a second reviewer accepts.
